import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import StatusBadge from "@/components/StatusBadge";
import {
  useVendors,
  useDiscussions,
  usePayments,
  useStock,
  updateBooking,
  addDiscussion,
} from "@/data/store";
import type { Booking, MenuPlate, BookingInventoryUse } from "@/data/mock";
import { formatINR } from "@/data/mock";
import { Plus, Send, Trash2 } from "lucide-react";

const uid = (p: string) => `${p}${Math.random().toString(36).slice(2, 8)}`;

export default function BookingDetail({ booking }: { booking: Booking }) {
  const vendors = useVendors();
  const discussions = useDiscussions();
  const payments = usePayments();
  const stock = useStock();

  const decor = booking.decor ?? { lights: "", dj: "", stageDecor: "", chairs: booking.guests };
  const menu = booking.menu ?? [];
  const inv = booking.inventoryUsage ?? [];

  const [draft, setDraft] = useState("");

  const setDecor = <K extends keyof typeof decor>(k: K, v: (typeof decor)[K]) =>
    updateBooking(booking.id, { decor: { ...decor, [k]: v } });

  const addMenu = () =>
    updateBooking(booking.id, {
      menu: [...menu, { id: uid("m"), course: "Course", items: "", pricePerPlate: 0 }],
    });
  const updateMenu = (id: string, p: Partial<MenuPlate>) =>
    updateBooking(booking.id, { menu: menu.map((m) => (m.id === id ? { ...m, ...p } : m)) });
  const removeMenu = (id: string) =>
    updateBooking(booking.id, { menu: menu.filter((m) => m.id !== id) });

  const addInv = () => {
    const firstUnused = stock.find((s) => !inv.some((i) => i.itemId === s.id));
    if (!firstUnused) return;
    updateBooking(booking.id, { inventoryUsage: [...inv, { itemId: firstUnused.id, quantity: 1 }] });
  };
  const updateInv = (idx: number, p: Partial<BookingInventoryUse>) =>
    updateBooking(booking.id, {
      inventoryUsage: inv.map((x, i) => (i === idx ? { ...x, ...p } : x)),
    });
  const removeInv = (idx: number) =>
    updateBooking(booking.id, { inventoryUsage: inv.filter((_, i) => i !== idx) });

  const send = () => {
    if (!draft.trim()) return;
    addDiscussion({ bookingId: booking.id, author: "Atelier", role: "owner", message: draft.trim() });
    setDraft("");
  };

  const thread = discussions.filter((d) => d.bookingId === booking.id);
  const bookingPayments = payments.filter((p) => p.bookingId === booking.id);
  const platePerGuest = menu.reduce((s, m) => s + m.pricePerPlate, 0);

  return (
    <Tabs defaultValue="vendors" className="w-full">
      <TabsList className="flex flex-wrap h-auto">
        <TabsTrigger value="vendors">Vendors</TabsTrigger>
        <TabsTrigger value="decor">Decor</TabsTrigger>
        <TabsTrigger value="menu">Menu plate</TabsTrigger>
        <TabsTrigger value="inventory">Inventory</TabsTrigger>
        <TabsTrigger value="discussion">Discussion</TabsTrigger>
        <TabsTrigger value="payment">Payment</TabsTrigger>
      </TabsList>

      <TabsContent value="vendors" className="space-y-2 pt-4">
        {booking.vendorIds.length === 0 && <div className="text-sm text-muted-foreground">No vendors assigned.</div>}
        {booking.vendorIds.map((id) => {
          const v = vendors.find((x) => x.id === id);
          if (!v) return null;
          return (
            <div key={id} className="rounded-md border border-border bg-surface px-4 py-3 grid grid-cols-1 sm:grid-cols-4 gap-2 text-sm">
              <div><div className="text-xs uppercase tracking-wider text-muted-foreground">Vendor</div><div className="font-medium">{v.name}</div></div>
              <div><div className="text-xs uppercase tracking-wider text-muted-foreground">Category</div><div>{v.category}</div></div>
              <div><div className="text-xs uppercase tracking-wider text-muted-foreground">Contact</div><div>{v.contact}</div></div>
              <div><div className="text-xs uppercase tracking-wider text-muted-foreground">Rating · Rate</div><div>★ {v.rating} · {formatINR(v.rate)}</div></div>
            </div>
          );
        })}
      </TabsContent>

      <TabsContent value="decor" className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-4">
        <div><Label>Lights</Label><Input value={decor.lights} onChange={(e) => setDecor("lights", e.target.value)} placeholder="Warm amber wash…" /></div>
        <div><Label>DJ</Label><Input value={decor.dj} onChange={(e) => setDecor("dj", e.target.value)} placeholder="DJ name + set length" /></div>
        <div className="md:col-span-2"><Label>Stage decor</Label><Textarea value={decor.stageDecor} onChange={(e) => setDecor("stageDecor", e.target.value)} placeholder="Mandap, backdrop, florals…" /></div>
        <div><Label>Chairs</Label><Input type="number" value={decor.chairs} onChange={(e) => setDecor("chairs", Number(e.target.value))} /></div>
      </TabsContent>

      <TabsContent value="menu" className="space-y-2 pt-4">
        <div className="flex items-center justify-between">
          <div className="text-sm text-muted-foreground">{menu.length} course{menu.length === 1 ? "" : "s"} · {formatINR(platePerGuest)} / plate · {formatINR(platePerGuest * booking.guests)} total</div>
          <Button size="sm" variant="outline" onClick={addMenu}><Plus className="h-3.5 w-3.5 mr-1" />Add course</Button>
        </div>
        {menu.map((m) => (
          <div key={m.id} className="grid grid-cols-12 gap-2 items-end rounded-md border border-border bg-surface px-3 py-2">
            <div className="col-span-3"><Label className="text-xs">Course</Label><Input value={m.course} onChange={(e) => updateMenu(m.id, { course: e.target.value })} /></div>
            <div className="col-span-6"><Label className="text-xs">Items</Label><Input value={m.items} onChange={(e) => updateMenu(m.id, { items: e.target.value })} /></div>
            <div className="col-span-2"><Label className="text-xs">₹ / plate</Label><Input type="number" value={m.pricePerPlate} onChange={(e) => updateMenu(m.id, { pricePerPlate: Number(e.target.value) })} /></div>
            <Button variant="ghost" size="icon" className="col-span-1" onClick={() => removeMenu(m.id)}><Trash2 className="h-4 w-4" /></Button>
          </div>
        ))}
        {menu.length === 0 && <div className="text-sm text-muted-foreground">No courses yet.</div>}
      </TabsContent>

      <TabsContent value="inventory" className="space-y-2 pt-4">
        <div className="flex items-center justify-between">
          <div className="text-sm text-muted-foreground">Stock allocated for this booking</div>
          <Button size="sm" variant="outline" onClick={addInv}><Plus className="h-3.5 w-3.5 mr-1" />Add item</Button>
        </div>
        {inv.map((u, idx) => {
          const item = stock.find((s) => s.id === u.itemId);
          return (
            <div key={idx} className="grid grid-cols-12 gap-2 items-end rounded-md border border-border bg-surface px-3 py-2">
              <div className="col-span-7">
                <Label className="text-xs">Item</Label>
                <Select value={u.itemId} onValueChange={(v) => updateInv(idx, { itemId: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {stock.map((s) => <SelectItem key={s.id} value={s.id}>{s.name} ({s.category})</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="col-span-3"><Label className="text-xs">Qty {item ? `(${item.unit})` : ""}</Label><Input type="number" value={u.quantity} onChange={(e) => updateInv(idx, { quantity: Number(e.target.value) })} /></div>
              <div className="col-span-1 text-xs text-muted-foreground pb-2">{item ? formatINR(item.costPerUnit * u.quantity) : ""}</div>
              <Button variant="ghost" size="icon" className="col-span-1" onClick={() => removeInv(idx)}><Trash2 className="h-4 w-4" /></Button>
            </div>
          );
        })}
        {inv.length === 0 && <div className="text-sm text-muted-foreground">No inventory linked.</div>}
      </TabsContent>

      <TabsContent value="discussion" className="pt-4">
        <div className="space-y-3 max-h-72 overflow-y-auto pr-1">
          {thread.map((m) => (
            <div key={m.id} className="rounded-md bg-surface px-3 py-2">
              <div className="text-xs text-muted-foreground mb-0.5">{m.author} · <span className="capitalize">{m.role}</span> · {new Date(m.at).toLocaleString("en-US", { dateStyle: "medium", timeStyle: "short" })}</div>
              <div className="text-sm">{m.message}</div>
            </div>
          ))}
          {thread.length === 0 && <div className="text-sm text-muted-foreground">No messages yet.</div>}
        </div>
        <div className="flex gap-2 mt-3">
          <Input value={draft} onChange={(e) => setDraft(e.target.value)} onKeyDown={(e) => e.key === "Enter" && send()} placeholder="Write a message…" />
          <Button onClick={send}><Send className="h-4 w-4" /></Button>
        </div>
      </TabsContent>

      <TabsContent value="payment" className="pt-4 space-y-2">
        {bookingPayments.length === 0 && <div className="text-sm text-muted-foreground">No payments recorded.</div>}
        {bookingPayments.map((p) => (
          <div key={p.id} className="flex items-center justify-between rounded-md bg-surface px-3 py-2 text-sm">
            <div>
              <div className="font-medium">{formatINR(p.amount)}</div>
              <div className="text-xs text-muted-foreground">{new Date(p.date).toLocaleDateString()} · <span className="capitalize">{p.method}</span>{p.note ? ` · ${p.note}` : ""}</div>
            </div>
            <StatusBadge status={p.status} />
          </div>
        ))}
        <div className="text-xs text-muted-foreground pt-2">Record new payments from the Payments page.</div>
      </TabsContent>
    </Tabs>
  );
}
