import { cn } from "@/lib/utils";

type Status =
  | "confirmed" | "tentative" | "completed" | "cancelled"
  | "new" | "contacted" | "qualified" | "lost" | "converted"
  | "paid" | "due" | "overdue";

const styles: Record<Status, string> = {
  confirmed: "bg-primary/10 text-primary",
  tentative: "bg-warning/15 text-warning",
  completed: "bg-muted text-muted-foreground",
  cancelled: "bg-destructive/10 text-destructive",
  new: "bg-primary/10 text-primary",
  contacted: "bg-accent/10 text-accent",
  qualified: "bg-success/15 text-success",
  converted: "bg-success/15 text-success",
  lost: "bg-muted text-muted-foreground",
  paid: "bg-success/15 text-success",
  due: "bg-warning/15 text-warning",
  overdue: "bg-destructive/10 text-destructive",
};

export default function StatusBadge({ status, className }: { status: Status; className?: string }) {
  return (
    <span className={cn("inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium capitalize", styles[status], className)}>
      {status}
    </span>
  );
}
