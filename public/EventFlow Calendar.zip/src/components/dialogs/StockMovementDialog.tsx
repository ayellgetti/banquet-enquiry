import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { recordMovement, useStock } from "@/data/store";

type Props = {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  itemId?: string;
};

export default function StockMovementDialog({ open, onOpenChange, itemId }: Props) {
  const stock = useStock();
  const [form, setForm] = useState({ itemId: "", type: "in" as "in" | "out" | "adjust", quantity: 0, note: "" });

  useEffect(() => {
    if (!open) return;
    setForm({ itemId: itemId ?? stock[0]?.id ?? "", type: "in", quantity: 0, note: "" });
  }, [open, itemId, stock]);

  const submit = () => {
    if (!form.itemId || form.quantity < 0) return;
    recordMovement(form);
    onOpenChange(false);
  };

  const set = <K extends keyof typeof form>(k: K, v: (typeof form)[K]) => setForm((f) => ({ ...f, [k]: v }));
  const current = stock.find((s) => s.id === form.itemId);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="font-serif-display text-2xl">Stock movement</DialogTitle>
          <DialogDescription>Record stock in, out, or adjust to a known count.</DialogDescription>
        </DialogHeader>
        <div className="grid gap-3">
          <div>
            <Label>Item</Label>
            <Select value={form.itemId} onValueChange={(v) => set("itemId", v)}>
              <SelectTrigger><SelectValue placeholder="Choose item" /></SelectTrigger>
              <SelectContent>
                {stock.map((s) => <SelectItem key={s.id} value={s.id}>{s.name} ({s.unit})</SelectItem>)}
              </SelectContent>
            </Select>
            {current && <p className="text-xs text-muted-foreground mt-1">Current: {current.quantity} {current.unit}</p>}
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Type</Label>
              <Select value={form.type} onValueChange={(v) => set("type", v as typeof form.type)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="in">Stock in</SelectItem>
                  <SelectItem value="out">Stock out</SelectItem>
                  <SelectItem value="adjust">Adjust to</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div><Label>Quantity</Label><Input type="number" value={form.quantity} onChange={(e) => set("quantity", Number(e.target.value))} /></div>
          </div>
          <div><Label>Note</Label><Textarea value={form.note} onChange={(e) => set("note", e.target.value)} /></div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={submit}>Save movement</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
