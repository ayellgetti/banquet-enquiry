import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { addPayment, updatePayment, useBookings, useCustomers } from "@/data/store";
import type { Payment } from "@/data/mock";

type Props = {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  initial?: Payment | null;
};

const today = () => new Date().toISOString().slice(0, 10);
const empty: Omit<Payment, "id"> = {
  bookingId: "", customerId: "", amount: 0, method: "card", status: "paid", date: today(), note: "",
};

export default function PaymentDialog({ open, onOpenChange, initial }: Props) {
  const bookings = useBookings();
  const customers = useCustomers();
  const [form, setForm] = useState<Omit<Payment, "id">>(empty);

  useEffect(() => {
    if (!open) return;
    if (initial) setForm({ ...initial });
    else setForm({ ...empty, bookingId: bookings[0]?.id ?? "", customerId: bookings[0]?.customerId ?? customers[0]?.id ?? "" });
  }, [open, initial, bookings, customers]);

  const set = <K extends keyof typeof form>(k: K, v: (typeof form)[K]) => setForm((f) => ({ ...f, [k]: v }));

  const submit = () => {
    if (!form.bookingId || !form.customerId || !form.amount) return;
    if (initial) updatePayment(initial.id, form);
    else addPayment(form);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="font-serif-display text-2xl">{initial ? "Edit payment" : "Record payment"}</DialogTitle>
          <DialogDescription>Log retainers, balances, and reconciliations.</DialogDescription>
        </DialogHeader>
        <div className="grid grid-cols-2 gap-3">
          <div className="col-span-2">
            <Label>Booking</Label>
            <Select value={form.bookingId} onValueChange={(v) => {
              const b = bookings.find((x) => x.id === v);
              setForm((f) => ({ ...f, bookingId: v, customerId: b?.customerId ?? f.customerId }));
            }}>
              <SelectTrigger><SelectValue placeholder="Choose booking" /></SelectTrigger>
              <SelectContent>
                {bookings.map((b) => <SelectItem key={b.id} value={b.id}>{b.title}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="col-span-2">
            <Label>Customer</Label>
            <Select value={form.customerId} onValueChange={(v) => set("customerId", v)}>
              <SelectTrigger><SelectValue placeholder="Customer" /></SelectTrigger>
              <SelectContent>
                {customers.map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div><Label>Amount (INR)</Label><Input type="number" value={form.amount} onChange={(e) => set("amount", Number(e.target.value))} /></div>
          <div><Label>Date</Label><Input type="date" value={form.date} onChange={(e) => set("date", e.target.value)} /></div>
          <div>
            <Label>Method</Label>
            <Select value={form.method} onValueChange={(v) => set("method", v as Payment["method"])}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {(["card", "bank", "cash"] as const).map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Status</Label>
            <Select value={form.status} onValueChange={(v) => set("status", v as Payment["status"])}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {(["paid", "due", "overdue"] as const).map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="col-span-2"><Label>Note</Label><Textarea value={form.note ?? ""} onChange={(e) => set("note", e.target.value)} /></div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={submit}>{initial ? "Save changes" : "Record payment"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
