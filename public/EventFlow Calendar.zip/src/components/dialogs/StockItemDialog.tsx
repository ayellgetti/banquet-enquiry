import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { addStockItem, updateStockItem, type StockItem, type StockCategory } from "@/data/store";

type Props = {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  initial?: StockItem | null;
};

const empty = {
  name: "", category: "Rice" as StockCategory, unit: "kg",
  quantity: 0, reorderLevel: 0, costPerUnit: 0, supplier: "",
};

export default function StockItemDialog({ open, onOpenChange, initial }: Props) {
  const [form, setForm] = useState(empty);

  useEffect(() => {
    if (!open) return;
    if (initial) {
      const { id: _id, updatedAt: _u, ...rest } = initial;
      setForm({ supplier: "", ...rest });
    } else setForm(empty);
  }, [open, initial]);

  const set = <K extends keyof typeof form>(k: K, v: (typeof form)[K]) => setForm((f) => ({ ...f, [k]: v }));

  const submit = () => {
    if (!form.name.trim() || !form.unit.trim()) return;
    if (initial) updateStockItem(initial.id, form);
    else addStockItem(form);
    onOpenChange(false);
  };

  const categories: StockCategory[] = ["Rice", "Dal", "Kirana", "Masala", "Other"];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="font-serif-display text-2xl">{initial ? "Edit item" : "New stock item"}</DialogTitle>
          <DialogDescription>Track rice, dal, kirana and masala inventory.</DialogDescription>
        </DialogHeader>
        <div className="grid grid-cols-2 gap-3">
          <div className="col-span-2"><Label>Item name</Label><Input value={form.name} onChange={(e) => set("name", e.target.value)} /></div>
          <div>
            <Label>Category</Label>
            <Select value={form.category} onValueChange={(v) => set("category", v as StockCategory)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{categories.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div><Label>Unit (kg, g, L, pcs)</Label><Input value={form.unit} onChange={(e) => set("unit", e.target.value)} /></div>
          <div><Label>Quantity on hand</Label><Input type="number" value={form.quantity} onChange={(e) => set("quantity", Number(e.target.value))} /></div>
          <div><Label>Reorder level</Label><Input type="number" value={form.reorderLevel} onChange={(e) => set("reorderLevel", Number(e.target.value))} /></div>
          <div><Label>Cost per unit (INR)</Label><Input type="number" value={form.costPerUnit} onChange={(e) => set("costPerUnit", Number(e.target.value))} /></div>
          <div><Label>Supplier</Label><Input value={form.supplier} onChange={(e) => set("supplier", e.target.value)} /></div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={submit}>{initial ? "Save changes" : "Add item"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
