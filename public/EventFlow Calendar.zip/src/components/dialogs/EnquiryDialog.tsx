import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { addEnquiry, updateEnquiry, useCustomers, useEventTypes, findOrCreateCustomer, getCustomer } from "@/data/store";
import type { Enquiry } from "@/data/mock";
import { toast } from "sonner";

type Props = {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  initial?: Enquiry | null;
  presetDate?: string;
};

const today = () => new Date().toISOString().slice(0, 10);

type FormState = {
  name: string;
  phone: string;
  eventType: string;
  preferredDate: string;
  guests: number;
  budget: number;
  status: Enquiry["status"];
  note: string;
};

const emptyForm = (): FormState => ({
  name: "", phone: "", eventType: "", preferredDate: today(),
  guests: 50, budget: 0, status: "new", note: "",
});

export default function EnquiryDialog({ open, onOpenChange, initial, presetDate }: Props) {
  const customers = useCustomers();
  const eventTypes = useEventTypes();
  const [form, setForm] = useState<FormState>(emptyForm());

  useEffect(() => {
    if (!open) return;
    if (initial) {
      const c = customers.find((x) => x.id === initial.customerId);
      setForm({
        name: c?.name ?? "",
        phone: c?.phone ?? "",
        eventType: initial.eventType,
        preferredDate: initial.preferredDate,
        guests: initial.guests,
        budget: initial.budget,
        status: initial.status,
        note: initial.note,
      });
    } else {
      setForm({ ...emptyForm(), preferredDate: presetDate ?? today(), eventType: eventTypes[0] ?? "" });
    }
  }, [open, initial, presetDate]);

  const set = <K extends keyof FormState>(k: K, v: FormState[K]) => setForm((f) => ({ ...f, [k]: v }));

  const submit = () => {
    if (!form.name.trim() || !form.phone.trim()) {
      toast.error("Name and phone are required");
      return;
    }
    if (!form.eventType.trim()) {
      toast.error("Event type is required");
      return;
    }
    if (initial) {
      // update existing customer name/phone if changed
      const cust = getCustomer(initial.customerId);
      const customerId = cust ? initial.customerId : findOrCreateCustomer(form.name, form.phone);
      updateEnquiry(initial.id, {
        customerId,
        eventType: form.eventType,
        preferredDate: form.preferredDate,
        guests: form.guests,
        budget: form.budget,
        status: form.status,
        note: form.note,
      });
    } else {
      const customerId = findOrCreateCustomer(form.name, form.phone);
      addEnquiry({
        customerId,
        eventType: form.eventType,
        preferredDate: form.preferredDate,
        guests: form.guests,
        budget: form.budget,
        status: form.status,
        note: form.note,
        createdAt: today(),
      });
    }
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="font-serif-display text-2xl">{initial ? "Edit enquiry" : "Log enquiry"}</DialogTitle>
          <DialogDescription>Customer is created automatically from name and phone.</DialogDescription>
        </DialogHeader>
        <div className="grid grid-cols-2 gap-3">
          <div><Label>Customer name</Label><Input value={form.name} onChange={(e) => set("name", e.target.value)} placeholder="Full name" /></div>
          <div><Label>Phone</Label><Input value={form.phone} onChange={(e) => set("phone", e.target.value)} placeholder="+91 …" /></div>
          <div>
            <Label>Event type</Label>
            <Select value={form.eventType} onValueChange={(v) => set("eventType", v)}>
              <SelectTrigger><SelectValue placeholder="Choose" /></SelectTrigger>
              <SelectContent>
                {eventTypes.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div><Label>Preferred date</Label><Input type="date" value={form.preferredDate} onChange={(e) => set("preferredDate", e.target.value)} /></div>
          <div><Label>Guests</Label><Input type="number" value={form.guests} onChange={(e) => set("guests", Number(e.target.value))} /></div>
          <div><Label>Budget (INR)</Label><Input type="number" value={form.budget} onChange={(e) => set("budget", Number(e.target.value))} /></div>
          <div className="col-span-2">
            <Label>Status</Label>
            <Select value={form.status} onValueChange={(v) => set("status", v as Enquiry["status"])}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {(["new", "contacted", "qualified", "converted", "lost"] as const).map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="col-span-2"><Label>Note</Label><Textarea rows={3} value={form.note} onChange={(e) => set("note", e.target.value)} /></div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={submit}>{initial ? "Save changes" : "Log enquiry"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
