import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { addBooking, updateBooking, useCustomers, useEventTypes } from "@/data/store";
import type { Booking } from "@/data/mock";

type Props = {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  initial?: Booking | null;
  presetDate?: string;
};

const today = () => new Date().toISOString().slice(0, 10);
const empty: Omit<Booking, "id"> = {
  customerId: "", title: "", eventType: "", date: today(),
  startTime: "18:00", endTime: "22:00", venue: "", guests: 100,
  status: "tentative", total: 0, vendorIds: [], requirements: [],
};

export default function BookingDialog({ open, onOpenChange, initial, presetDate }: Props) {
  const customers = useCustomers();
  const eventTypes = useEventTypes();
  const [form, setForm] = useState<Omit<Booking, "id">>(empty);

  useEffect(() => {
    if (!open) return;
    if (initial) setForm({ ...initial });
    else setForm({ ...empty, date: presetDate ?? today(), customerId: customers[0]?.id ?? "" });
  }, [open, initial, presetDate, customers]);

  const set = <K extends keyof typeof form>(k: K, v: (typeof form)[K]) => setForm((f) => ({ ...f, [k]: v }));

  const submit = () => {
    if (!form.title.trim() || !form.customerId) return;
    if (initial) updateBooking(initial.id, form);
    else addBooking(form);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-xl">
        <DialogHeader>
          <DialogTitle className="font-serif-display text-2xl">{initial ? "Edit booking" : "New booking"}</DialogTitle>
          <DialogDescription>Lock in the essentials — refine vendors and requirements after.</DialogDescription>
        </DialogHeader>
        <div className="grid grid-cols-2 gap-3">
          <div className="col-span-2"><Label>Event title</Label><Input value={form.title} onChange={(e) => set("title", e.target.value)} /></div>
          <div>
            <Label>Customer</Label>
            <Select value={form.customerId} onValueChange={(v) => set("customerId", v)}>
              <SelectTrigger><SelectValue placeholder="Choose customer" /></SelectTrigger>
              <SelectContent>
                {customers.map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Event type</Label>
            <Select value={form.eventType} onValueChange={(v) => set("eventType", v)}>
              <SelectTrigger><SelectValue placeholder="Choose" /></SelectTrigger>
              <SelectContent>
                {eventTypes.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div><Label>Date</Label><Input type="date" value={form.date} onChange={(e) => set("date", e.target.value)} /></div>
          <div>
            <Label>Status</Label>
            <Select value={form.status} onValueChange={(v) => set("status", v as Booking["status"])}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {(["confirmed", "tentative", "completed", "cancelled"] as const).map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div><Label>Start time</Label><Input type="time" value={form.startTime} onChange={(e) => set("startTime", e.target.value)} /></div>
          <div><Label>End time</Label><Input type="time" value={form.endTime} onChange={(e) => set("endTime", e.target.value)} /></div>
          <div className="col-span-2"><Label>Venue</Label><Input value={form.venue} onChange={(e) => set("venue", e.target.value)} /></div>
          <div><Label>Guests</Label><Input type="number" value={form.guests} onChange={(e) => set("guests", Number(e.target.value))} /></div>
          <div><Label>Total (INR)</Label><Input type="number" value={form.total} onChange={(e) => set("total", Number(e.target.value))} /></div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={submit}>{initial ? "Save changes" : "Create booking"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
