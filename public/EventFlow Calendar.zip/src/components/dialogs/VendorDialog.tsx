import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { addVendor, updateVendor } from "@/data/store";
import type { Vendor } from "@/data/mock";

type Props = { open: boolean; onOpenChange: (o: boolean) => void; initial?: Vendor | null };

const empty = { name: "", category: "", contact: "", rating: 4.5, rate: 0 };

export default function VendorDialog({ open, onOpenChange, initial }: Props) {
  const [form, setForm] = useState(empty);

  useEffect(() => {
    if (open) setForm(initial ? { ...empty, ...initial } : empty);
  }, [open, initial]);

  const set = <K extends keyof typeof form>(k: K, v: (typeof form)[K]) => setForm((f) => ({ ...f, [k]: v }));

  const submit = () => {
    if (!form.name.trim()) return;
    const payload = { ...form, rating: Number(form.rating) || 0, rate: Number(form.rate) || 0 };
    if (initial) updateVendor(initial.id, payload);
    else addVendor(payload);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="font-serif-display text-2xl">{initial ? "Edit vendor" : "Add vendor"}</DialogTitle>
          <DialogDescription>Partners you bring to bookings.</DialogDescription>
        </DialogHeader>
        <div className="grid grid-cols-2 gap-3">
          <div className="col-span-2"><Label>Name</Label><Input value={form.name} onChange={(e) => set("name", e.target.value)} /></div>
          <div><Label>Category</Label><Input value={form.category} onChange={(e) => set("category", e.target.value)} placeholder="Catering, Decor…" /></div>
          <div><Label>Contact</Label><Input value={form.contact} onChange={(e) => set("contact", e.target.value)} /></div>
          <div><Label>Rating</Label><Input type="number" step="0.1" min="0" max="5" value={form.rating} onChange={(e) => set("rating", Number(e.target.value))} /></div>
          <div><Label>Starting rate (INR)</Label><Input type="number" value={form.rate} onChange={(e) => set("rate", Number(e.target.value))} /></div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={submit}>{initial ? "Save changes" : "Add vendor"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
