import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { addCustomer, updateCustomer } from "@/data/store";
import type { Customer } from "@/data/mock";

type Props = { open: boolean; onOpenChange: (o: boolean) => void; initial?: Customer | null };

const empty = { name: "", email: "", phone: "", company: "", since: new Date().toISOString().slice(0, 10), totalSpend: 0 };

export default function CustomerDialog({ open, onOpenChange, initial }: Props) {
  const [form, setForm] = useState(empty);

  useEffect(() => {
    if (open) setForm(initial ? { ...empty, ...initial, company: initial.company ?? "" } : empty);
  }, [open, initial]);

  const set = <K extends keyof typeof form>(k: K, v: (typeof form)[K]) => setForm((f) => ({ ...f, [k]: v }));

  const submit = () => {
    if (!form.name.trim()) return;
    const payload = { ...form, totalSpend: Number(form.totalSpend) || 0, company: form.company || undefined };
    if (initial) updateCustomer(initial.id, payload);
    else addCustomer(payload);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="font-serif-display text-2xl">{initial ? "Edit customer" : "Add customer"}</DialogTitle>
          <DialogDescription>Contact details and lifetime value.</DialogDescription>
        </DialogHeader>
        <div className="grid grid-cols-2 gap-3">
          <div className="col-span-2"><Label>Name</Label><Input value={form.name} onChange={(e) => set("name", e.target.value)} /></div>
          <div><Label>Email</Label><Input type="email" value={form.email} onChange={(e) => set("email", e.target.value)} /></div>
          <div><Label>Phone</Label><Input value={form.phone} onChange={(e) => set("phone", e.target.value)} /></div>
          <div><Label>Company</Label><Input value={form.company} onChange={(e) => set("company", e.target.value)} /></div>
          <div><Label>Customer since</Label><Input type="date" value={form.since} onChange={(e) => set("since", e.target.value)} /></div>
          <div className="col-span-2"><Label>Total spend (INR)</Label><Input type="number" value={form.totalSpend} onChange={(e) => set("totalSpend", Number(e.target.value))} /></div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={submit}>{initial ? "Save changes" : "Add customer"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
