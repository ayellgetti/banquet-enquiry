import { NavLink, Outlet } from "react-router-dom";
import { Calendar, Users, Inbox, ClipboardList, MessageSquare, Truck, Wallet, Sparkles, Package, Settings } from "lucide-react";
import { cn } from "@/lib/utils";

const nav = [
  { to: "/", label: "Calendar", icon: Calendar, end: true },
  { to: "/enquiries", label: "Enquiries", icon: Inbox },
  { to: "/customers", label: "Customers", icon: Users },
  { to: "/bookings", label: "Bookings", icon: ClipboardList },
  { to: "/discussions", label: "Discussions", icon: MessageSquare },
  { to: "/vendors", label: "Vendors", icon: Truck },
  { to: "/inventory", label: "Inventory", icon: Package },
  { to: "/payments", label: "Payments", icon: Wallet },
  { to: "/settings", label: "Settings", icon: Settings },
];

export default function AppLayout() {
  return (
    <div className="min-h-screen bg-surface">
      <div className="flex">
        <aside className="hidden md:flex w-64 shrink-0 flex-col border-r border-border bg-sidebar h-screen sticky top-0">
          <div className="px-6 py-6 border-b border-border">
            <div className="flex items-center gap-2">
              <div className="h-9 w-9 rounded-lg bg-primary/10 flex items-center justify-center">
                <Sparkles className="h-5 w-5 text-primary" />
              </div>
              <div>
                <div className="font-serif-display text-xl leading-none">Atelier</div>
                <div className="text-xs text-muted-foreground mt-1">Event Suite</div>
              </div>
            </div>
          </div>
          <nav className="flex-1 px-3 py-4 space-y-1">
            {nav.map(({ to, label, icon: Icon, end }) => (
              <NavLink
                key={to}
                to={to}
                end={end}
                className={({ isActive }) =>
                  cn(
                    "flex items-center gap-3 px-3 py-2.5 rounded-md text-sm transition-colors",
                    isActive
                      ? "bg-primary/10 text-primary font-medium"
                      : "text-sidebar-foreground hover:bg-sidebar-accent"
                  )
                }
              >
                <Icon className="h-4 w-4" />
                {label}
              </NavLink>
            ))}
          </nav>
          <div className="p-4 border-t border-border">
            <div className="rounded-lg bg-gradient-to-br from-primary/10 to-transparent p-4">
              <p className="font-serif-display text-lg leading-tight">Boutique events, beautifully run.</p>
              <p className="text-xs text-muted-foreground mt-2">Demo workspace · v1.0</p>
            </div>
          </div>
        </aside>

        <main className="flex-1 min-w-0">
          {/* Mobile nav */}
          <div className="md:hidden sticky top-0 z-20 bg-background/90 backdrop-blur border-b border-border">
            <div className="px-4 py-3 flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-primary" />
              <span className="font-serif-display text-lg">Atelier</span>
            </div>
            <div className="flex gap-1 px-2 pb-2 overflow-x-auto">
              {nav.map(({ to, label, icon: Icon, end }) => (
                <NavLink
                  key={to}
                  to={to}
                  end={end}
                  className={({ isActive }) =>
                    cn(
                      "flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs whitespace-nowrap",
                      isActive ? "bg-primary/10 text-primary" : "text-muted-foreground"
                    )
                  }
                >
                  <Icon className="h-3.5 w-3.5" />
                  {label}
                </NavLink>
              ))}
            </div>
          </div>

          <div className="p-6 md:p-10 max-w-[1400px]">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  );
}
