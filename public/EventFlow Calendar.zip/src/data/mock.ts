export type Customer = {
  id: string;
  name: string;
  email: string;
  phone: string;
  company?: string;
  since: string;
  totalSpend: number;
};

export type Enquiry = {
  id: string;
  customerId: string;
  eventType: string;
  preferredDate: string;
  guests: number;
  budget: number;
  status: "new" | "contacted" | "qualified" | "lost" | "converted";
  note: string;
  createdAt: string;
  bookingId?: string;
};

export type BookingDecor = {
  lights: string;
  dj: string;
  stageDecor: string;
  chairs: number;
};

export type MenuPlate = {
  id: string;
  course: string; // Starter, Main, Dessert, Beverage…
  items: string;
  pricePerPlate: number;
};

export type BookingInventoryUse = {
  itemId: string;
  quantity: number;
};

export type Booking = {
  id: string;
  customerId: string;
  title: string;
  eventType: string;
  date: string; // ISO yyyy-mm-dd
  startTime: string;
  endTime: string;
  venue: string;
  guests: number;
  status: "confirmed" | "tentative" | "completed" | "cancelled";
  requirements: { id: string; label: string; done: boolean }[];
  vendorIds: string[];
  total: number;
  decor?: BookingDecor;
  menu?: MenuPlate[];
  inventoryUsage?: BookingInventoryUse[];
};

export type Vendor = {
  id: string;
  name: string;
  category: string;
  contact: string;
  rating: number;
  rate: number;
};

export type DiscussionMessage = {
  id: string;
  bookingId: string;
  author: string;
  role: "owner" | "customer" | "vendor";
  message: string;
  at: string;
};

export type Payment = {
  id: string;
  bookingId: string;
  customerId: string;
  amount: number;
  method: "card" | "bank" | "cash";
  status: "paid" | "due" | "overdue";
  date: string;
  note?: string;
};

export const customers: Customer[] = [
  { id: "c1", name: "Aarav Mehta", email: "aarav@kanvas.co", phone: "+91 98200 11221", company: "Kanvas Studio", since: "2024-02-10", totalSpend: 480000 },
  { id: "c2", name: "Priya Shah", email: "priya.shah@gmail.com", phone: "+91 99876 22113", since: "2024-08-04", totalSpend: 220000 },
  { id: "c3", name: "Rohan & Neha", email: "rohan.neha@wed.in", phone: "+91 98330 55678", since: "2025-01-22", totalSpend: 1850000 },
  { id: "c4", name: "Vertex Labs", email: "events@vertex.io", phone: "+91 80470 99000", company: "Vertex Labs", since: "2023-11-30", totalSpend: 920000 },
  { id: "c5", name: "Isha Kapoor", email: "isha@studio-noir.com", phone: "+91 97411 30022", company: "Studio Noir", since: "2025-03-18", totalSpend: 165000 },
];

export const vendors: Vendor[] = [
  { id: "v1", name: "Lumen Light Co.", category: "Lighting", contact: "ops@lumen.co", rating: 4.8, rate: 45000 },
  { id: "v2", name: "Saffron Catering", category: "Catering", contact: "book@saffron.in", rating: 4.7, rate: 1250 },
  { id: "v3", name: "Maison Florals", category: "Florals", contact: "hello@maison.fl", rating: 4.9, rate: 60000 },
  { id: "v4", name: "Echo Sound", category: "Audio", contact: "team@echosound.in", rating: 4.6, rate: 38000 },
  { id: "v5", name: "Frame & Folk", category: "Photography", contact: "studio@frameandfolk.com", rating: 4.9, rate: 85000 },
  { id: "v6", name: "Mirage Decor", category: "Decor", contact: "info@miragedecor.in", rating: 4.5, rate: 120000 },
];

// Build dates around "today" so the calendar always has activity
const today = new Date();
const offset = (d: number) => {
  const x = new Date(today);
  x.setDate(today.getDate() + d);
  return x.toISOString().slice(0, 10);
};

export const bookings: Booking[] = [
  {
    id: "b1", customerId: "c3", title: "Rohan & Neha — Sangeet", eventType: "Wedding",
    date: offset(2), startTime: "18:00", endTime: "23:30", venue: "The Leela Palace, Ballroom A",
    guests: 320, status: "confirmed", total: 850000, vendorIds: ["v1", "v2", "v3", "v5"],
    requirements: [
      { id: "r1", label: "Stage design approved", done: true },
      { id: "r2", label: "Catering tasting", done: true },
      { id: "r3", label: "Lighting walkthrough", done: false },
      { id: "r4", label: "Run-of-show signed", done: false },
    ],
    decor: { lights: "Warm amber wash, fairy canopy", dj: "DJ Ravi — 4 hr Bollywood set", stageDecor: "Mirrored mandap with floral arch", chairs: 320 },
    menu: [
      { id: "m1", course: "Welcome", items: "Paani puri, kebab platter", pricePerPlate: 350 },
      { id: "m2", course: "Main", items: "Dal makhani, paneer, biryani, naan", pricePerPlate: 1200 },
      { id: "m3", course: "Dessert", items: "Gulab jamun, kulfi", pricePerPlate: 220 },
    ],
    inventoryUsage: [
      { itemId: "s1", quantity: 40 },
      { itemId: "s3", quantity: 12 },
      { itemId: "s9", quantity: 1 },
    ],
  },
  {
    id: "b2", customerId: "c4", title: "Vertex Q3 Summit", eventType: "Corporate",
    date: offset(5), startTime: "09:00", endTime: "17:00", venue: "ITC Gardenia, Hall 2",
    guests: 180, status: "confirmed", total: 540000, vendorIds: ["v4", "v2", "v6"],
    requirements: [
      { id: "r1", label: "AV check", done: true },
      { id: "r2", label: "Badge printing", done: false },
      { id: "r3", label: "Speaker green room", done: false },
    ],
  },
  {
    id: "b3", customerId: "c1", title: "Kanvas Launch Soirée", eventType: "Brand",
    date: offset(-3), startTime: "19:00", endTime: "23:00", venue: "Rooftop, UB City",
    guests: 90, status: "completed", total: 260000, vendorIds: ["v1", "v3", "v5"],
    requirements: [
      { id: "r1", label: "Guest list locked", done: true },
      { id: "r2", label: "Photographer brief", done: true },
    ],
  },
  {
    id: "b4", customerId: "c2", title: "Priya — Sweet 30", eventType: "Private",
    date: offset(9), startTime: "20:00", endTime: "01:00", venue: "Private Villa, Whitefield",
    guests: 60, status: "tentative", total: 180000, vendorIds: ["v2", "v6"],
    requirements: [
      { id: "r1", label: "Menu confirmation", done: false },
      { id: "r2", label: "Decor moodboard", done: true },
    ],
  },
  {
    id: "b5", customerId: "c5", title: "Studio Noir — Press Preview", eventType: "Brand",
    date: offset(14), startTime: "11:00", endTime: "15:00", venue: "Gallery 51",
    guests: 45, status: "confirmed", total: 145000, vendorIds: ["v3", "v5"],
    requirements: [
      { id: "r1", label: "Press kits printed", done: false },
      { id: "r2", label: "Catering passed apps", done: false },
    ],
  },
  {
    id: "b6", customerId: "c3", title: "Rohan & Neha — Reception", eventType: "Wedding",
    date: offset(3), startTime: "19:30", endTime: "00:30", venue: "The Leela Palace, Lawn",
    guests: 450, status: "confirmed", total: 1000000, vendorIds: ["v1", "v2", "v3", "v5", "v6"],
    requirements: [
      { id: "r1", label: "Final headcount", done: true },
      { id: "r2", label: "Fireworks permit", done: false },
    ],
  },
];

export const enquiries: Enquiry[] = [
  { id: "e1", customerId: "c2", eventType: "Birthday", preferredDate: offset(20), guests: 60, budget: 200000, status: "qualified", note: "Outdoor preferred. Vegetarian menu.", createdAt: offset(-4) },
  { id: "e2", customerId: "c5", eventType: "Press Preview", preferredDate: offset(14), guests: 45, budget: 150000, status: "contacted", note: "Needs printed press kits.", createdAt: offset(-6) },
  { id: "e3", customerId: "c1", eventType: "Pop-up Brand", preferredDate: offset(30), guests: 120, budget: 350000, status: "new", note: "Looking for a curated rooftop space.", createdAt: offset(-1) },
  { id: "e4", customerId: "c4", eventType: "Town Hall", preferredDate: offset(40), guests: 250, budget: 600000, status: "new", note: "Hybrid event, livestream required.", createdAt: offset(0) },
];

export const discussions: DiscussionMessage[] = [
  { id: "d1", bookingId: "b1", author: "Atelier", role: "owner", message: "Sharing the final stage layout — please review the entry arch placement.", at: offset(-2) + "T10:14:00" },
  { id: "d2", bookingId: "b1", author: "Rohan", role: "customer", message: "Looks beautiful. Can we add warmer lighting near the mandap?", at: offset(-2) + "T11:02:00" },
  { id: "d3", bookingId: "b1", author: "Lumen Light Co.", role: "vendor", message: "Noted — switching to 2700K wash + amber uplights.", at: offset(-1) + "T09:30:00" },
  { id: "d4", bookingId: "b2", author: "Vertex Labs", role: "customer", message: "Please confirm AV runs for the keynote at 10:00.", at: offset(-1) + "T16:20:00" },
  { id: "d5", bookingId: "b2", author: "Echo Sound", role: "vendor", message: "Confirmed. Backup wireless on standby.", at: offset(0) + "T08:05:00" },
];

export const payments: Payment[] = [
  { id: "p1", bookingId: "b1", customerId: "c3", amount: 425000, method: "bank", status: "paid", date: offset(-30), note: "50% retainer" },
  { id: "p2", bookingId: "b1", customerId: "c3", amount: 425000, method: "bank", status: "due", date: offset(1), note: "Balance due before event" },
  { id: "p3", bookingId: "b2", customerId: "c4", amount: 270000, method: "card", status: "paid", date: offset(-12) },
  { id: "p4", bookingId: "b2", customerId: "c4", amount: 270000, method: "bank", status: "due", date: offset(4) },
  { id: "p5", bookingId: "b3", customerId: "c1", amount: 260000, method: "card", status: "paid", date: offset(-15) },
  { id: "p6", bookingId: "b4", customerId: "c2", amount: 90000, method: "card", status: "paid", date: offset(-5) },
  { id: "p7", bookingId: "b4", customerId: "c2", amount: 90000, method: "card", status: "due", date: offset(8) },
  { id: "p8", bookingId: "b5", customerId: "c5", amount: 72500, method: "bank", status: "overdue", date: offset(-2) },
  { id: "p9", bookingId: "b6", customerId: "c3", amount: 500000, method: "bank", status: "paid", date: offset(-20) },
];

export const formatINR = (n: number) =>
  new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(n);

export const customerById = (id: string) => customers.find((c) => c.id === id);
export const vendorById = (id: string) => vendors.find((v) => v.id === id);
export const bookingById = (id: string) => bookings.find((b) => b.id === id);
