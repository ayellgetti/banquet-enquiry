import { useSyncExternalStore } from "react";
import {
  bookings as seedBookings,
  enquiries as seedEnquiries,
  customers as seedCustomers,
  vendors as seedVendors,
  payments as seedPayments,
  discussions as seedDiscussions,
  type Booking,
  type Enquiry,
  type Customer,
  type Vendor,
  type Payment,
  type DiscussionMessage,
} from "./mock";

export type StockCategory = "Rice" | "Dal" | "Kirana" | "Masala" | "Other";
export type StockItem = {
  id: string;
  name: string;
  category: StockCategory;
  unit: string; // kg, g, L, pcs
  quantity: number;
  reorderLevel: number;
  costPerUnit: number;
  supplier?: string;
  updatedAt: string;
};
export type StockMovement = {
  id: string;
  itemId: string;
  type: "in" | "out" | "adjust";
  quantity: number;
  note?: string;
  at: string;
};

const seedStock: StockItem[] = [
  { id: "s1", name: "Basmati Rice", category: "Rice", unit: "kg", quantity: 120, reorderLevel: 30, costPerUnit: 95, supplier: "Daawat Traders", updatedAt: new Date().toISOString() },
  { id: "s2", name: "Sona Masoori", category: "Rice", unit: "kg", quantity: 80, reorderLevel: 25, costPerUnit: 62, supplier: "Sri Krishna Mills", updatedAt: new Date().toISOString() },
  { id: "s3", name: "Toor Dal", category: "Dal", unit: "kg", quantity: 45, reorderLevel: 20, costPerUnit: 140, supplier: "Anand Pulses", updatedAt: new Date().toISOString() },
  { id: "s4", name: "Moong Dal", category: "Dal", unit: "kg", quantity: 18, reorderLevel: 20, costPerUnit: 130, supplier: "Anand Pulses", updatedAt: new Date().toISOString() },
  { id: "s5", name: "Chana Dal", category: "Dal", unit: "kg", quantity: 32, reorderLevel: 15, costPerUnit: 110, supplier: "Anand Pulses", updatedAt: new Date().toISOString() },
  { id: "s6", name: "Sunflower Oil", category: "Kirana", unit: "L", quantity: 40, reorderLevel: 15, costPerUnit: 165, supplier: "Fortune Foods", updatedAt: new Date().toISOString() },
  { id: "s7", name: "Sugar", category: "Kirana", unit: "kg", quantity: 60, reorderLevel: 20, costPerUnit: 45, supplier: "Madhur Sugar", updatedAt: new Date().toISOString() },
  { id: "s8", name: "Wheat Atta", category: "Kirana", unit: "kg", quantity: 90, reorderLevel: 25, costPerUnit: 48, supplier: "Aashirvaad", updatedAt: new Date().toISOString() },
  { id: "s9", name: "Turmeric Powder", category: "Masala", unit: "kg", quantity: 8, reorderLevel: 5, costPerUnit: 280, supplier: "MDH", updatedAt: new Date().toISOString() },
  { id: "s10", name: "Red Chilli Powder", category: "Masala", unit: "kg", quantity: 6, reorderLevel: 5, costPerUnit: 320, supplier: "Everest", updatedAt: new Date().toISOString() },
  { id: "s11", name: "Garam Masala", category: "Masala", unit: "kg", quantity: 3, reorderLevel: 4, costPerUnit: 520, supplier: "Everest", updatedAt: new Date().toISOString() },
  { id: "s12", name: "Cumin Seeds", category: "Masala", unit: "kg", quantity: 4, reorderLevel: 3, costPerUnit: 480, supplier: "Local Mandi", updatedAt: new Date().toISOString() },
];

export type MenuPlateTemplate = {
  id: string;
  name: string;
  course: string;
  items: string;
  pricePerPlate: number;
};

type State = {
  customers: Customer[];
  vendors: Vendor[];
  bookings: Booking[];
  enquiries: Enquiry[];
  payments: Payment[];
  discussions: DiscussionMessage[];
  stock: StockItem[];
  movements: StockMovement[];
  eventTypes: string[];
  menuTemplates: MenuPlateTemplate[];
};

let state: State = {
  customers: [...seedCustomers],
  vendors: [...seedVendors],
  bookings: [...seedBookings],
  enquiries: [...seedEnquiries],
  payments: [...seedPayments],
  discussions: [...seedDiscussions],
  stock: seedStock,
  movements: [],
  eventTypes: ["Wedding", "Corporate", "Birthday", "Brand", "Private", "Press Preview", "Town Hall"],
  menuTemplates: [
    { id: "mt1", name: "Classic Veg Welcome", course: "Welcome", items: "Paani puri, kebab platter, mocktails", pricePerPlate: 350 },
    { id: "mt2", name: "North Indian Main", course: "Main", items: "Dal makhani, paneer butter masala, biryani, naan", pricePerPlate: 1200 },
    { id: "mt3", name: "Indian Dessert", course: "Dessert", items: "Gulab jamun, kulfi, rasmalai", pricePerPlate: 220 },
  ],
};

const listeners = new Set<() => void>();
const subscribe = (cb: () => void) => {
  listeners.add(cb);
  return () => listeners.delete(cb);
};
const emit = () => listeners.forEach((cb) => cb());
const patch = (p: Partial<State>) => {
  state = { ...state, ...p };
  emit();
};

const uid = (prefix: string) =>
  `${prefix}${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;

export const useCustomers = () => useSyncExternalStore(subscribe, () => state.customers);
export const useVendors = () => useSyncExternalStore(subscribe, () => state.vendors);
export const useBookings = () => useSyncExternalStore(subscribe, () => state.bookings);
export const useEnquiries = () => useSyncExternalStore(subscribe, () => state.enquiries);
export const usePayments = () => useSyncExternalStore(subscribe, () => state.payments);
export const useDiscussions = () => useSyncExternalStore(subscribe, () => state.discussions);

export const addDiscussion = (d: Omit<DiscussionMessage, "id" | "at">) =>
  patch({ discussions: [...state.discussions, { ...d, id: uid("d"), at: new Date().toISOString() }] });

export const getCustomer = (id: string) => state.customers.find((c) => c.id === id);
export const getVendor = (id: string) => state.vendors.find((v) => v.id === id);
export const getBooking = (id: string) => state.bookings.find((b) => b.id === id);

export const addCustomer = (c: Omit<Customer, "id">) => {
  const id = uid("c");
  patch({ customers: [...state.customers, { ...c, id }] });
  return id;
};
export const updateCustomer = (id: string, p: Partial<Customer>) =>
  patch({ customers: state.customers.map((x) => (x.id === id ? { ...x, ...p } : x)) });

export const findOrCreateCustomer = (name: string, phone: string): string => {
  const n = name.trim();
  const p = phone.trim();
  const existing = state.customers.find(
    (c) => (p && c.phone.replace(/\s+/g, "") === p.replace(/\s+/g, "")) || (!p && c.name.toLowerCase() === n.toLowerCase())
  );
  if (existing) return existing.id;
  return addCustomer({
    name: n || "New customer",
    email: "",
    phone: p,
    since: new Date().toISOString().slice(0, 10),
    totalSpend: 0,
  });
};

export const addVendor = (v: Omit<Vendor, "id">) =>
  patch({ vendors: [...state.vendors, { ...v, id: uid("v") }] });
export const updateVendor = (id: string, p: Partial<Vendor>) =>
  patch({ vendors: state.vendors.map((x) => (x.id === id ? { ...x, ...p } : x)) });

export const addBooking = (b: Omit<Booking, "id">) => {
  const id = uid("b");
  patch({ bookings: [...state.bookings, { ...b, id }] });
  return id;
};
export const updateBooking = (id: string, p: Partial<Booking>) =>
  patch({ bookings: state.bookings.map((x) => (x.id === id ? { ...x, ...p } : x)) });

export const convertEnquiryToBooking = (enquiryId: string): string | null => {
  const e = state.enquiries.find((x) => x.id === enquiryId);
  if (!e) return null;
  if (e.bookingId) return e.bookingId;
  const customer = state.customers.find((c) => c.id === e.customerId);
  const bookingId = addBooking({
    customerId: e.customerId,
    title: `${customer?.name ?? "Client"} — ${e.eventType}`,
    eventType: e.eventType,
    date: e.preferredDate,
    startTime: "18:00",
    endTime: "22:00",
    venue: "",
    guests: e.guests,
    status: "tentative",
    total: e.budget,
    vendorIds: [],
    requirements: [
      { id: uid("r"), label: "Confirm venue", done: false },
      { id: uid("r"), label: "Assign vendors", done: false },
      { id: uid("r"), label: "Finalize decor", done: false },
      { id: uid("r"), label: "Lock menu & inventory", done: false },
    ],
    decor: { lights: "", dj: "", stageDecor: "", chairs: e.guests },
    menu: [],
    inventoryUsage: [],
  });
  patch({
    enquiries: state.enquiries.map((x) =>
      x.id === enquiryId ? { ...x, status: "converted", bookingId } : x
    ),
  });
  return bookingId;
};

export const addEnquiry = (e: Omit<Enquiry, "id">) =>
  patch({ enquiries: [...state.enquiries, { ...e, id: uid("e") }] });
export const updateEnquiry = (id: string, p: Partial<Enquiry>) =>
  patch({ enquiries: state.enquiries.map((x) => (x.id === id ? { ...x, ...p } : x)) });

export const addPayment = (p: Omit<Payment, "id">) =>
  patch({ payments: [...state.payments, { ...p, id: uid("p") }] });
export const updatePayment = (id: string, p: Partial<Payment>) =>
  patch({ payments: state.payments.map((x) => (x.id === id ? { ...x, ...p } : x)) });

export const useStock = () => useSyncExternalStore(subscribe, () => state.stock);
export const useMovements = () => useSyncExternalStore(subscribe, () => state.movements);
export const getStockItem = (id: string) => state.stock.find((s) => s.id === id);

export const addStockItem = (s: Omit<StockItem, "id" | "updatedAt">) =>
  patch({ stock: [...state.stock, { ...s, id: uid("s"), updatedAt: new Date().toISOString() }] });
export const updateStockItem = (id: string, p: Partial<StockItem>) =>
  patch({ stock: state.stock.map((x) => (x.id === id ? { ...x, ...p, updatedAt: new Date().toISOString() } : x)) });
export const deleteStockItem = (id: string) =>
  patch({ stock: state.stock.filter((x) => x.id !== id) });

export const recordMovement = (m: Omit<StockMovement, "id" | "at">) => {
  const item = state.stock.find((s) => s.id === m.itemId);
  if (!item) return;
  const delta = m.type === "in" ? m.quantity : m.type === "out" ? -m.quantity : m.quantity - item.quantity;
  const newQty = m.type === "adjust" ? m.quantity : Math.max(0, item.quantity + (m.type === "in" ? m.quantity : -m.quantity));
  patch({
    stock: state.stock.map((x) => (x.id === m.itemId ? { ...x, quantity: newQty, updatedAt: new Date().toISOString() } : x)),
    movements: [{ ...m, id: uid("mv"), at: new Date().toISOString() }, ...state.movements],
  });
  void delta;
};

// Settings: event types
export const useEventTypes = () => useSyncExternalStore(subscribe, () => state.eventTypes);
export const addEventType = (name: string) => {
  const n = name.trim();
  if (!n || state.eventTypes.includes(n)) return;
  patch({ eventTypes: [...state.eventTypes, n] });
};
export const removeEventType = (name: string) =>
  patch({ eventTypes: state.eventTypes.filter((x) => x !== name) });

// Settings: menu plate templates
export const useMenuTemplates = () => useSyncExternalStore(subscribe, () => state.menuTemplates);
export const addMenuTemplate = (m: Omit<MenuPlateTemplate, "id">) =>
  patch({ menuTemplates: [...state.menuTemplates, { ...m, id: uid("mt") }] });
export const updateMenuTemplate = (id: string, p: Partial<MenuPlateTemplate>) =>
  patch({ menuTemplates: state.menuTemplates.map((x) => (x.id === id ? { ...x, ...p } : x)) });
export const removeMenuTemplate = (id: string) =>
  patch({ menuTemplates: state.menuTemplates.filter((x) => x.id !== id) });

