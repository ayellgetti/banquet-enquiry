import { useState } from "react";
import { useNavigate } from "react-router-dom";
import PageHeader from "@/components/PageHeader";
import StatusBadge from "@/components/StatusBadge";
import { Button } from "@/components/ui/button";
import { useEnquiries, useCustomers, useBookings, convertEnquiryToBooking } from "@/data/store";
import { formatINR } from "@/data/mock";
import { Plus, Inbox, Pencil, ArrowRight, CheckCircle2 } from "lucide-react";
import EnquiryDialog from "@/components/dialogs/EnquiryDialog";
import { toast } from "sonner";
import type { Enquiry } from "@/data/mock";

export default function EnquiriesPage() {
  const enquiries = useEnquiries();
  const customers = useCustomers();
  const bookings = useBookings();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Enquiry | null>(null);

  const startAdd = () => { setEditing(null); setOpen(true); };
  const startEdit = (e: Enquiry) => { setEditing(e); setOpen(true); };
  const customerById = (id: string) => customers.find((c) => c.id === id);
  const bookingById = (id?: string) => bookings.find((b) => b.id === id);

  const convert = (e: Enquiry) => {
    const id = convertEnquiryToBooking(e.id);
    if (!id) return;
    toast.success("Converted to booking", {
      description: "Now assign vendors, decor and inventory.",
      action: { label: "Open booking", onClick: () => navigate("/bookings") },
    });
  };

  return (
    <div>
      <PageHeader
        eyebrow="Pipeline"
        title="Enquiries"
        description="Incoming requests waiting to be qualified into bookings."
        actions={<Button size="sm" onClick={startAdd}><Plus className="h-4 w-4 mr-1.5" />Log enquiry</Button>}
      />

      <div className="rounded-2xl border border-border bg-card shadow-soft overflow-hidden">
        <div className="hidden md:grid grid-cols-[1.4fr_1fr_1fr_0.7fr_1fr_0.9fr_0.8fr] gap-4 px-6 py-3 bg-surface text-xs uppercase tracking-wider text-muted-foreground border-b border-border">
          <div>Client</div><div>Event</div><div>Preferred date</div><div>Guests</div><div>Budget</div><div>Status</div><div className="text-right">Actions</div>
        </div>
        {enquiries.map((e) => {
          const c = customerById(e.customerId);
          const linked = bookingById(e.bookingId);
          return (
            <div key={e.id} className="grid grid-cols-1 md:grid-cols-[1.4fr_1fr_1fr_0.7fr_1fr_0.9fr_0.8fr] gap-2 md:gap-4 px-6 py-4 border-b border-border last:border-0 hover:bg-surface/60 items-center">
              <div>
                <div className="font-medium">{c?.name ?? "—"}</div>
                <div className="text-xs text-muted-foreground">{c?.email}</div>
                {e.note && <div className="text-xs text-muted-foreground mt-1 italic">"{e.note}"</div>}
                {linked && (
                  <button onClick={() => navigate("/bookings")} className="text-xs text-success mt-1 inline-flex items-center gap-1 hover:underline">
                    <CheckCircle2 className="h-3 w-3" /> Linked: {linked.title}
                  </button>
                )}
              </div>
              <div className="text-sm">{e.eventType}</div>
              <div className="text-sm">{new Date(e.preferredDate).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}</div>
              <div className="text-sm">{e.guests}</div>
              <div className="text-sm">{formatINR(e.budget)}</div>
              <div><StatusBadge status={e.status} /></div>
              <div className="flex items-center gap-1 justify-end">
                {!linked && e.status !== "lost" && (
                  <Button variant="outline" size="sm" onClick={() => convert(e)}>
                    Convert <ArrowRight className="h-3.5 w-3.5 ml-1" />
                  </Button>
                )}
                <Button variant="ghost" size="icon" onClick={() => startEdit(e)}><Pencil className="h-4 w-4" /></Button>
              </div>
            </div>
          );
        })}
        {enquiries.length === 0 && (
          <div className="p-12 text-center text-muted-foreground">
            <Inbox className="h-8 w-8 mx-auto mb-2 opacity-60" />
            No enquiries yet.
          </div>
        )}
      </div>

      <EnquiryDialog open={open} onOpenChange={setOpen} initial={editing} />
    </div>
  );
}
