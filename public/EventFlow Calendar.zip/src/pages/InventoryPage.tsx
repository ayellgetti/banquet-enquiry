import { useMemo, useState } from "react";
import PageHeader from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Plus, ArrowDownUp, Pencil, Trash2, Search, AlertTriangle } from "lucide-react";
import { useStock, deleteStockItem, type StockItem, type StockCategory } from "@/data/store";
import { formatINR } from "@/data/mock";
import StockItemDialog from "@/components/dialogs/StockItemDialog";
import StockMovementDialog from "@/components/dialogs/StockMovementDialog";

const categories: ("All" | StockCategory)[] = ["All", "Rice", "Dal", "Kirana", "Masala", "Other"];

export default function InventoryPage() {
  const stock = useStock();
  const [cat, setCat] = useState<"All" | StockCategory>("All");
  const [q, setQ] = useState("");
  const [itemOpen, setItemOpen] = useState(false);
  const [editing, setEditing] = useState<StockItem | null>(null);
  const [moveOpen, setMoveOpen] = useState(false);
  const [moveItem, setMoveItem] = useState<string | undefined>();

  const filtered = useMemo(() => {
    return stock.filter((s) =>
      (cat === "All" || s.category === cat) &&
      (q.trim() === "" || s.name.toLowerCase().includes(q.toLowerCase()) || s.supplier?.toLowerCase().includes(q.toLowerCase()))
    );
  }, [stock, cat, q]);

  const totalValue = stock.reduce((s, i) => s + i.quantity * i.costPerUnit, 0);
  const lowCount = stock.filter((s) => s.quantity <= s.reorderLevel).length;
  const outCount = stock.filter((s) => s.quantity === 0).length;

  const openNew = () => { setEditing(null); setItemOpen(true); };
  const openEdit = (s: StockItem) => { setEditing(s); setItemOpen(true); };
  const openMove = (id?: string) => { setMoveItem(id); setMoveOpen(true); };

  return (
    <div>
      <PageHeader
        eyebrow="Operations"
        title="Inventory"
        description="Rice, dal, kirana and masala — stock levels, reorder alerts, and movements."
        actions={
          <div className="flex gap-2">
            <Button size="sm" variant="outline" onClick={() => openMove()}><ArrowDownUp className="h-4 w-4 mr-1.5" />Movement</Button>
            <Button size="sm" onClick={openNew}><Plus className="h-4 w-4 mr-1.5" />New item</Button>
          </div>
        }
      />

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="rounded-xl border border-border bg-card p-5 shadow-soft">
          <div className="text-xs uppercase tracking-wider text-muted-foreground">Inventory value</div>
          <div className="font-serif-display text-3xl mt-2">{formatINR(totalValue)}</div>
        </div>
        <div className="rounded-xl border border-border bg-card p-5 shadow-soft">
          <div className="text-xs uppercase tracking-wider text-muted-foreground">Low stock</div>
          <div className="font-serif-display text-3xl mt-2 text-warning">{lowCount}</div>
        </div>
        <div className="rounded-xl border border-border bg-card p-5 shadow-soft">
          <div className="text-xs uppercase tracking-wider text-muted-foreground">Out of stock</div>
          <div className="font-serif-display text-3xl mt-2 text-destructive">{outCount}</div>
        </div>
      </div>

      <div className="flex flex-col md:flex-row md:items-center gap-3 mb-4">
        <Tabs value={cat} onValueChange={(v) => setCat(v as typeof cat)}>
          <TabsList>
            {categories.map((c) => <TabsTrigger key={c} value={c}>{c}</TabsTrigger>)}
          </TabsList>
        </Tabs>
        <div className="relative md:ml-auto md:w-80">
          <Search className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <Input className="pl-9" placeholder="Search item or supplier" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
      </div>

      <div className="rounded-2xl border border-border bg-card shadow-soft overflow-hidden">
        <div className="hidden md:grid grid-cols-[1.6fr_0.8fr_0.8fr_0.8fr_1fr_1fr_0.8fr] gap-4 px-6 py-3 bg-surface text-xs uppercase tracking-wider text-muted-foreground border-b border-border">
          <div>Item</div><div>Category</div><div>Quantity</div><div>Reorder</div><div>Cost / unit</div><div>Value</div><div className="text-right">Actions</div>
        </div>
        {filtered.map((s) => {
          const low = s.quantity <= s.reorderLevel;
          const out = s.quantity === 0;
          return (
            <div key={s.id} className="grid grid-cols-1 md:grid-cols-[1.6fr_0.8fr_0.8fr_0.8fr_1fr_1fr_0.8fr] gap-2 md:gap-4 px-6 py-4 border-b border-border last:border-0 hover:bg-surface/60">
              <div>
                <div className="font-medium flex items-center gap-2">
                  {s.name}
                  {out ? <Badge variant="destructive">Out</Badge> : low ? <Badge className="bg-warning text-warning-foreground"><AlertTriangle className="h-3 w-3 mr-1" />Low</Badge> : null}
                </div>
                {s.supplier && <div className="text-xs text-muted-foreground">{s.supplier}</div>}
              </div>
              <div className="text-sm">{s.category}</div>
              <div className="text-sm">{s.quantity} {s.unit}</div>
              <div className="text-sm text-muted-foreground">{s.reorderLevel} {s.unit}</div>
              <div className="text-sm">{formatINR(s.costPerUnit)}</div>
              <div className="text-sm font-medium">{formatINR(s.quantity * s.costPerUnit)}</div>
              <div className="flex md:justify-end gap-1.5">
                <Button size="sm" variant="ghost" onClick={() => openMove(s.id)}><ArrowDownUp className="h-4 w-4" /></Button>
                <Button size="sm" variant="ghost" onClick={() => openEdit(s)}><Pencil className="h-4 w-4" /></Button>
                <Button size="sm" variant="ghost" onClick={() => { if (confirm(`Delete ${s.name}?`)) deleteStockItem(s.id); }}><Trash2 className="h-4 w-4" /></Button>
              </div>
            </div>
          );
        })}
        {filtered.length === 0 && <div className="px-6 py-10 text-center text-muted-foreground text-sm">No items found.</div>}
      </div>

      <StockItemDialog open={itemOpen} onOpenChange={setItemOpen} initial={editing} />
      <StockMovementDialog open={moveOpen} onOpenChange={setMoveOpen} itemId={moveItem} />
    </div>
  );
}
