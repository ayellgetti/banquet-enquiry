import { useState } from "react";
import PageHeader from "@/components/PageHeader";
import StatusBadge from "@/components/StatusBadge";
import { Button } from "@/components/ui/button";
import { usePayments, getCustomer, getBooking } from "@/data/store";
import { formatINR, type Payment } from "@/data/mock";
import { Plus, ArrowUpRight, Pencil } from "lucide-react";
import PaymentDialog from "@/components/dialogs/PaymentDialog";

export default function PaymentsPage() {
  const payments = usePayments();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Payment | null>(null);

  const totalCollected = payments.filter(p => p.status === "paid").reduce((s, p) => s + p.amount, 0);
  const totalDue = payments.filter(p => p.status === "due").reduce((s, p) => s + p.amount, 0);
  const totalOverdue = payments.filter(p => p.status === "overdue").reduce((s, p) => s + p.amount, 0);

  const stats = [
    { label: "Collected", value: formatINR(totalCollected), tone: "text-success" },
    { label: "Outstanding", value: formatINR(totalDue), tone: "text-warning" },
    { label: "Overdue", value: formatINR(totalOverdue), tone: "text-destructive" },
  ];

  const sorted = [...payments].sort((a, b) => b.date.localeCompare(a.date));

  const openNew = () => { setEditing(null); setOpen(true); };
  const openEdit = (p: Payment) => { setEditing(p); setOpen(true); };

  return (
    <div>
      <PageHeader
        eyebrow="Finance"
        title="Payments"
        description="Retainers, balances and reconciliation across every booking."
        actions={<Button size="sm" onClick={openNew}><Plus className="h-4 w-4 mr-1.5" />Record payment</Button>}
      />

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        {stats.map((s) => (
          <div key={s.label} className="rounded-xl border border-border bg-card p-5 shadow-soft">
            <div className="text-xs uppercase tracking-wider text-muted-foreground">{s.label}</div>
            <div className={`font-serif-display text-3xl mt-2 ${s.tone}`}>{s.value}</div>
          </div>
        ))}
      </div>

      <div className="rounded-2xl border border-border bg-card shadow-soft overflow-hidden">
        <div className="hidden md:grid grid-cols-[1.4fr_1.6fr_1fr_0.8fr_1fr_0.8fr_0.5fr] gap-4 px-6 py-3 bg-surface text-xs uppercase tracking-wider text-muted-foreground border-b border-border">
          <div>Client</div><div>Booking</div><div>Date</div><div>Method</div><div>Amount</div><div>Status</div><div></div>
        </div>
        {sorted.map((p) => {
          const c = getCustomer(p.customerId);
          const b = getBooking(p.bookingId);
          return (
            <div key={p.id} className="grid grid-cols-1 md:grid-cols-[1.4fr_1.6fr_1fr_0.8fr_1fr_0.8fr_0.5fr] gap-2 md:gap-4 px-6 py-4 border-b border-border last:border-0 hover:bg-surface/60">
              <div>
                <div className="font-medium">{c?.name ?? "—"}</div>
                <div className="text-xs text-muted-foreground">{c?.email}</div>
              </div>
              <div className="text-sm flex items-start gap-1.5">
                <ArrowUpRight className="h-3.5 w-3.5 mt-0.5 text-muted-foreground" />
                <div>
                  <div>{b?.title ?? "—"}</div>
                  {p.note && <div className="text-xs text-muted-foreground italic">{p.note}</div>}
                </div>
              </div>
              <div className="text-sm">{new Date(p.date).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}</div>
              <div className="text-sm capitalize">{p.method}</div>
              <div className="text-sm font-medium">{formatINR(p.amount)}</div>
              <div><StatusBadge status={p.status} /></div>
              <div className="md:text-right"><Button size="sm" variant="ghost" onClick={() => openEdit(p)}><Pencil className="h-4 w-4" /></Button></div>
            </div>
          );
        })}
        {sorted.length === 0 && <div className="px-6 py-10 text-center text-muted-foreground text-sm">No payments yet. Record your first one.</div>}
      </div>

      <PaymentDialog open={open} onOpenChange={setOpen} initial={editing} />
    </div>
  );
}
