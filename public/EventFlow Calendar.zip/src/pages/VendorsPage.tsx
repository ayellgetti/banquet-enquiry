import { useState } from "react";
import PageHeader from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { useVendors, useBookings } from "@/data/store";
import { formatINR } from "@/data/mock";
import { Plus, Star, Pencil, LayoutGrid, List } from "lucide-react";
import VendorDialog from "@/components/dialogs/VendorDialog";
import type { Vendor } from "@/data/mock";
import { cn } from "@/lib/utils";

export default function VendorsPage() {
  const vendors = useVendors();
  const bookings = useBookings();
  const [view, setView] = useState<"grid" | "list">("grid");
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Vendor | null>(null);

  const startAdd = () => { setEditing(null); setOpen(true); };
  const startEdit = (v: Vendor) => { setEditing(v); setOpen(true); };
  const usedIn = (id: string) => bookings.filter((b) => b.vendorIds.includes(id)).length;

  return (
    <div>
      <PageHeader
        eyebrow="Network"
        title="Vendors"
        description="Trusted partners across catering, decor, lighting and more."
        actions={
          <>
            <div className="inline-flex rounded-md border border-border overflow-hidden">
              <button onClick={() => setView("grid")} className={cn("px-2.5 py-1.5", view === "grid" ? "bg-primary text-primary-foreground" : "bg-card text-muted-foreground")}><LayoutGrid className="h-4 w-4" /></button>
              <button onClick={() => setView("list")} className={cn("px-2.5 py-1.5", view === "list" ? "bg-primary text-primary-foreground" : "bg-card text-muted-foreground")}><List className="h-4 w-4" /></button>
            </div>
            <Button size="sm" onClick={startAdd}><Plus className="h-4 w-4 mr-1.5" />Add vendor</Button>
          </>
        }
      />

      {view === "grid" ? (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {vendors.map((v) => (
            <div key={v.id} className="rounded-2xl border border-border bg-card p-6 shadow-soft hover:shadow-elegant transition-shadow">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <div className="text-xs uppercase tracking-wider text-muted-foreground">{v.category}</div>
                  <div className="font-serif-display text-2xl mt-1 leading-tight truncate">{v.name}</div>
                </div>
                <div className="flex items-center gap-1">
                  <div className="flex items-center gap-1 text-sm">
                    <Star className="h-3.5 w-3.5 fill-warning text-warning" />
                    <span className="font-medium">{v.rating}</span>
                  </div>
                  <Button variant="ghost" size="icon" onClick={() => startEdit(v)}><Pencil className="h-4 w-4" /></Button>
                </div>
              </div>
              <div className="text-sm text-muted-foreground mt-2">{v.contact}</div>
              <div className="mt-4 pt-4 border-t border-border flex items-center justify-between text-sm">
                <div><div className="text-xs text-muted-foreground">Starting at</div><div className="font-medium">{formatINR(v.rate)}</div></div>
                <div className="text-right"><div className="text-xs text-muted-foreground">Used in</div><div className="font-medium">{usedIn(v.id)} events</div></div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="rounded-2xl border border-border bg-card shadow-soft overflow-hidden">
          <div className="hidden md:grid grid-cols-[1.4fr_1fr_1.2fr_0.6fr_1fr_0.6fr_0.4fr] gap-4 px-6 py-3 bg-surface text-xs uppercase tracking-wider text-muted-foreground border-b border-border">
            <div>Name</div><div>Category</div><div>Contact</div><div>Rating</div><div>Rate</div><div>Events</div><div></div>
          </div>
          {vendors.map((v) => (
            <div key={v.id} className="grid grid-cols-1 md:grid-cols-[1.4fr_1fr_1.2fr_0.6fr_1fr_0.6fr_0.4fr] gap-2 md:gap-4 px-6 py-4 border-b border-border last:border-0 hover:bg-surface/60 items-center">
              <div className="font-medium">{v.name}</div>
              <div className="text-sm">{v.category}</div>
              <div className="text-sm text-muted-foreground">{v.contact}</div>
              <div className="text-sm flex items-center gap-1"><Star className="h-3.5 w-3.5 fill-warning text-warning" />{v.rating}</div>
              <div className="text-sm font-medium">{formatINR(v.rate)}</div>
              <div className="text-sm">{usedIn(v.id)}</div>
              <div className="text-right"><Button variant="ghost" size="icon" onClick={() => startEdit(v)}><Pencil className="h-4 w-4" /></Button></div>
            </div>
          ))}
        </div>
      )}

      <VendorDialog open={open} onOpenChange={setOpen} initial={editing} />
    </div>
  );
}
