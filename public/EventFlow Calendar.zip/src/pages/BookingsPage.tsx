import { useState } from "react";
import PageHeader from "@/components/PageHeader";
import StatusBadge from "@/components/StatusBadge";
import { Button } from "@/components/ui/button";
import { useBookings, useCustomers } from "@/data/store";
import { formatINR } from "@/data/mock";
import { cn } from "@/lib/utils";
import { Plus, MapPin, Users as UsersIcon, ChevronDown, Pencil } from "lucide-react";
import BookingDialog from "@/components/dialogs/BookingDialog";
import BookingDetail from "@/components/BookingDetail";
import type { Booking } from "@/data/mock";

export default function BookingsPage() {
  const bookings = useBookings();
  const customers = useCustomers();
  const [openId, setOpenId] = useState<string | null>(bookings[0]?.id ?? null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<Booking | null>(null);

  const customerById = (id: string) => customers.find((c) => c.id === id);
  const sorted = [...bookings].sort((a, b) => a.date.localeCompare(b.date));

  const startAdd = () => { setEditing(null); setDialogOpen(true); };
  const startEdit = (b: Booking) => { setEditing(b); setDialogOpen(true); };

  return (
    <div>
      <PageHeader
        eyebrow="Operations"
        title="Bookings"
        description="Confirmed events with requirements, vendors and totals."
        actions={<Button size="sm" onClick={startAdd}><Plus className="h-4 w-4 mr-1.5" />New booking</Button>}
      />

      <div className="space-y-3">
        {sorted.map((b) => {
          const open = openId === b.id;
          const c = customerById(b.customerId);
          const done = b.requirements.filter((r) => r.done).length;
          return (
            <div key={b.id} className="rounded-2xl border border-border bg-card shadow-soft overflow-hidden">
              <div className="w-full px-6 py-5 flex items-center gap-4 hover:bg-surface/60">
                <button onClick={() => setOpenId(open ? null : b.id)} className="flex items-center gap-4 flex-1 text-left min-w-0">
                  <div className="text-center w-16 shrink-0">
                    <div className="text-xs uppercase tracking-wider text-muted-foreground">
                      {new Date(b.date).toLocaleString("en-US", { month: "short" })}
                    </div>
                    <div className="font-serif-display text-3xl leading-none">{new Date(b.date).getDate()}</div>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-serif-display text-xl">{b.title}</span>
                      <StatusBadge status={b.status} />
                    </div>
                    <div className="text-sm text-muted-foreground flex items-center gap-3 mt-1 flex-wrap">
                      <span className="flex items-center gap-1"><MapPin className="h-3.5 w-3.5" />{b.venue}</span>
                      <span className="flex items-center gap-1"><UsersIcon className="h-3.5 w-3.5" />{b.guests}</span>
                      <span>· {c?.name}</span>
                    </div>
                  </div>
                  <div className="hidden md:block text-right">
                    <div className="font-medium">{formatINR(b.total)}</div>
                    <div className="text-xs text-muted-foreground">{done}/{b.requirements.length} requirements</div>
                  </div>
                </button>
                <Button variant="ghost" size="icon" onClick={() => startEdit(b)}><Pencil className="h-4 w-4" /></Button>
                <ChevronDown className={cn("h-4 w-4 text-muted-foreground transition-transform", open && "rotate-180")} />
              </div>

              {open && (
                <div className="px-6 pb-6 border-t border-border pt-5 space-y-5">
                  <div>
                    <div className="text-xs uppercase tracking-wider text-muted-foreground mb-2">Requirements</div>
                    <ul className="grid grid-cols-1 sm:grid-cols-2 gap-y-1.5 gap-x-6">
                      {b.requirements.map((r) => (
                        <li key={r.id} className="flex items-center gap-2 text-sm">
                          <span className={cn("h-4 w-4 rounded border border-border flex items-center justify-center text-[10px]", r.done && "bg-success text-success-foreground border-success")}>
                            {r.done && "✓"}
                          </span>
                          <span className={cn(r.done && "line-through text-muted-foreground")}>{r.label}</span>
                        </li>
                      ))}
                      {b.requirements.length === 0 && <li className="text-sm text-muted-foreground">No requirements yet.</li>}
                    </ul>
                  </div>
                  <BookingDetail booking={b} />
                </div>
              )}
            </div>
          );
        })}
      </div>

      <BookingDialog open={dialogOpen} onOpenChange={setDialogOpen} initial={editing} />
    </div>
  );
}
