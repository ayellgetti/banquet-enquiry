import { useMemo, useState } from "react";
import { ChevronLeft, ChevronRight, Plus, Filter, Pencil, CalendarPlus } from "lucide-react";
import PageHeader from "@/components/PageHeader";
import StatusBadge from "@/components/StatusBadge";
import { Button } from "@/components/ui/button";
import { useBookings, useCustomers, useVendors } from "@/data/store";
import { formatINR } from "@/data/mock";
import type { Booking } from "@/data/mock";
import { cn } from "@/lib/utils";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import BookingDialog from "@/components/dialogs/BookingDialog";
import EnquiryDialog from "@/components/dialogs/EnquiryDialog";

const WEEKDAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

const startOfMonth = (d: Date) => new Date(d.getFullYear(), d.getMonth(), 1);
const endOfMonth = (d: Date) => new Date(d.getFullYear(), d.getMonth() + 1, 0);
const isoDay = (d: Date) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
const sameDay = (a: Date, b: Date) =>
  a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();

export default function CalendarPage() {
  const bookings = useBookings();
  const customers = useCustomers();
  const vendors = useVendors();
  const customerById = (id: string) => customers.find((c) => c.id === id);
  const vendorById = (id: string) => vendors.find((v) => v.id === id);

  const [cursor, setCursor] = useState(() => new Date());
  const [openId, setOpenId] = useState<string | null>(null);
  const [dayKey, setDayKey] = useState<string | null>(null);

  const [bookingDialog, setBookingDialog] = useState<{ open: boolean; date?: string; initial?: Booking | null }>({ open: false });
  const [enquiryDialog, setEnquiryDialog] = useState<{ open: boolean; date?: string }>({ open: false });

  const cells = useMemo(() => {
    const first = startOfMonth(cursor);
    const last = endOfMonth(cursor);
    const startPad = first.getDay();
    const totalDays = last.getDate();
    const out: { date: Date; inMonth: boolean }[] = [];
    for (let i = 0; i < startPad; i++) {
      const d = new Date(first); d.setDate(d.getDate() - (startPad - i));
      out.push({ date: d, inMonth: false });
    }
    for (let i = 1; i <= totalDays; i++) {
      out.push({ date: new Date(cursor.getFullYear(), cursor.getMonth(), i), inMonth: true });
    }
    while (out.length % 7 !== 0) {
      const d = new Date(out[out.length - 1].date); d.setDate(d.getDate() + 1);
      out.push({ date: d, inMonth: false });
    }
    return out;
  }, [cursor]);

  const byDate = useMemo(() => {
    const m = new Map<string, Booking[]>();
    bookings.forEach((b) => {
      const arr = m.get(b.date) ?? []; arr.push(b); m.set(b.date, arr);
    });
    return m;
  }, [bookings]);

  const today = new Date();
  const monthLabel = cursor.toLocaleString("en-US", { month: "long", year: "numeric" });

  const upcoming = useMemo(
    () => [...bookings]
      .filter((b) => new Date(b.date) >= new Date(isoDay(today)))
      .sort((a, b) => a.date.localeCompare(b.date))
      .slice(0, 4),
    [bookings] // eslint-disable-line react-hooks/exhaustive-deps
  );

  const openBooking = openId ? bookings.find((b) => b.id === openId) : null;
  const dayEvents = dayKey ? (byDate.get(dayKey) ?? []) : [];

  const stats = [
    { label: "Upcoming events", value: bookings.filter(b => new Date(b.date) >= new Date(isoDay(today))).length },
    { label: "Confirmed this month", value: bookings.filter(b => b.status === "confirmed" && new Date(b.date).getMonth() === cursor.getMonth()).length },
    { label: "Revenue (booked)", value: formatINR(bookings.reduce((s, b) => s + b.total, 0)) },
  ];

  return (
    <div>
      <PageHeader
        eyebrow="Workspace"
        title="Calendar"
        description="Every enquiry, booking and rehearsal at a glance. Tap a day to view event details."
        actions={
          <>
            <Button variant="outline" size="sm"><Filter className="h-4 w-4 mr-1.5" />Filter</Button>
            <Button size="sm" onClick={() => setBookingDialog({ open: true })}><Plus className="h-4 w-4 mr-1.5" />New booking</Button>
          </>
        }
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">
        {stats.map((s) => (
          <div key={s.label} className="rounded-xl border border-border bg-card p-5 shadow-soft">
            <div className="text-xs uppercase tracking-wider text-muted-foreground">{s.label}</div>
            <div className="font-serif-display text-3xl mt-2">{s.value}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-[1fr_320px] gap-6">
        <div className="rounded-2xl border border-border bg-card shadow-soft overflow-hidden">
          <div className="flex items-center justify-between px-5 py-4 border-b border-border">
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="icon" onClick={() => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() - 1, 1))}>
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <h2 className="font-serif-display text-2xl">{monthLabel}</h2>
              <Button variant="ghost" size="icon" onClick={() => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() + 1, 1))}>
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
            <Button variant="outline" size="sm" onClick={() => setCursor(new Date())}>Today</Button>
          </div>

          <div className="grid grid-cols-7 border-b border-border bg-surface">
            {WEEKDAYS.map((d) => (
              <div key={d} className="px-3 py-2 text-xs uppercase tracking-wider text-muted-foreground text-center">{d}</div>
            ))}
          </div>

          <div className="grid grid-cols-7 auto-rows-[minmax(110px,_1fr)]">
            {cells.map(({ date, inMonth }, i) => {
              const key = isoDay(date);
              const events = byDate.get(key) ?? [];
              const isToday = sameDay(date, today);
              return (
                <div
                  key={i}
                  onClick={() => setDayKey(key)}
                  className={cn(
                    "border-b border-r border-border p-2 flex flex-col gap-1 min-h-[110px] cursor-pointer hover:bg-surface/60 transition-colors",
                    !inMonth && "bg-muted/30 text-muted-foreground",
                    (i + 1) % 7 === 0 && "border-r-0"
                  )}
                >
                  <div className="flex items-center justify-between">
                    <span className={cn(
                      "text-xs font-medium inline-flex items-center justify-center h-6 w-6 rounded-full",
                      isToday && "bg-primary text-primary-foreground"
                    )}>
                      {date.getDate()}
                    </span>
                  </div>
                  <div className="flex flex-col gap-1 overflow-hidden">
                    {events.slice(0, 3).map((e) => (
                      <button
                        key={e.id}
                        onClick={(ev) => { ev.stopPropagation(); setOpenId(e.id); }}
                        className={cn(
                          "text-left text-[11px] leading-tight px-2 py-1 rounded-md truncate transition-colors",
                          e.status === "confirmed" && "bg-primary/10 text-primary hover:bg-primary/15",
                          e.status === "tentative" && "bg-warning/15 text-warning hover:bg-warning/20",
                          e.status === "completed" && "bg-muted text-muted-foreground hover:bg-muted/80",
                          e.status === "cancelled" && "bg-destructive/10 text-destructive line-through"
                        )}
                      >
                        <span className="font-medium">{e.startTime}</span> · {e.title}
                      </button>
                    ))}
                    {events.length > 3 && (
                      <span className="text-[10px] text-muted-foreground px-2">+{events.length - 3} more</span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <aside className="space-y-3">
          <h3 className="font-serif-display text-2xl">Upcoming</h3>
          {upcoming.map((b) => {
            const c = customerById(b.customerId);
            return (
              <button
                key={b.id}
                onClick={() => setOpenId(b.id)}
                className="w-full text-left rounded-xl border border-border bg-card p-4 hover:shadow-elegant transition-shadow"
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs uppercase tracking-wider text-muted-foreground">{b.eventType}</span>
                  <StatusBadge status={b.status} />
                </div>
                <div className="font-serif-display text-lg mt-1.5 leading-tight">{b.title}</div>
                <div className="text-sm text-muted-foreground mt-1">{new Date(b.date).toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" })} · {b.startTime}</div>
                <div className="text-xs text-muted-foreground mt-2">{c?.name} · {b.guests} guests</div>
              </button>
            );
          })}
        </aside>
      </div>

      {/* Day events dialog */}
      <Dialog open={!!dayKey} onOpenChange={(o) => !o && setDayKey(null)}>
        <DialogContent className="max-w-lg">
          {dayKey && (
            <>
              <DialogHeader>
                <DialogTitle className="font-serif-display text-2xl">
                  {new Date(dayKey).toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric", year: "numeric" })}
                </DialogTitle>
                <DialogDescription>
                  {dayEvents.length === 0 ? "Nothing scheduled. Add a booking or log an enquiry for this date." : `${dayEvents.length} event${dayEvents.length > 1 ? "s" : ""} on this day.`}
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-2 max-h-[50vh] overflow-y-auto">
                {dayEvents.map((e) => (
                  <div key={e.id} className="rounded-lg border border-border p-3 flex items-start gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-serif-display text-lg leading-tight">{e.title}</span>
                        <StatusBadge status={e.status} />
                      </div>
                      <div className="text-xs text-muted-foreground mt-1">
                        {e.startTime}–{e.endTime} · {e.venue} · {e.guests} guests
                      </div>
                      <div className="text-xs text-muted-foreground mt-0.5">{customerById(e.customerId)?.name}</div>
                    </div>
                    <Button variant="ghost" size="icon" onClick={() => { setDayKey(null); setOpenId(e.id); }}>
                      <Pencil className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
              <DialogFooter className="!flex-col sm:!flex-row sm:!justify-between gap-2">
                <Button variant="outline" onClick={() => { const d = dayKey; setDayKey(null); setEnquiryDialog({ open: true, date: d }); }}>
                  <CalendarPlus className="h-4 w-4 mr-1.5" />Log enquiry
                </Button>
                <Button onClick={() => { const d = dayKey; setDayKey(null); setBookingDialog({ open: true, date: d }); }}>
                  <Plus className="h-4 w-4 mr-1.5" />New booking
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* Booking detail dialog */}
      <Dialog open={!!openBooking} onOpenChange={(o) => !o && setOpenId(null)}>
        <DialogContent className="max-w-lg">
          {openBooking && (
            <>
              <DialogHeader>
                <div className="flex items-center gap-2 text-xs uppercase tracking-wider text-muted-foreground">
                  {openBooking.eventType} · <StatusBadge status={openBooking.status} />
                </div>
                <DialogTitle className="font-serif-display text-3xl">{openBooking.title}</DialogTitle>
                <DialogDescription>
                  {new Date(openBooking.date).toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric", year: "numeric" })} · {openBooking.startTime}–{openBooking.endTime}
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 text-sm">
                <div className="grid grid-cols-2 gap-3">
                  <div><div className="text-xs uppercase tracking-wider text-muted-foreground">Venue</div><div>{openBooking.venue}</div></div>
                  <div><div className="text-xs uppercase tracking-wider text-muted-foreground">Guests</div><div>{openBooking.guests}</div></div>
                  <div><div className="text-xs uppercase tracking-wider text-muted-foreground">Client</div><div>{customerById(openBooking.customerId)?.name}</div></div>
                  <div><div className="text-xs uppercase tracking-wider text-muted-foreground">Total</div><div>{formatINR(openBooking.total)}</div></div>
                </div>
                {openBooking.requirements.length > 0 && (
                  <div>
                    <div className="text-xs uppercase tracking-wider text-muted-foreground mb-2">Requirements</div>
                    <ul className="space-y-1.5">
                      {openBooking.requirements.map((r) => (
                        <li key={r.id} className="flex items-center gap-2">
                          <span className={cn("h-4 w-4 rounded border border-border flex items-center justify-center text-[10px]", r.done && "bg-success text-success-foreground border-success")}>
                            {r.done && "✓"}
                          </span>
                          <span className={cn(r.done && "line-through text-muted-foreground")}>{r.label}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
                {openBooking.vendorIds.length > 0 && (
                  <div>
                    <div className="text-xs uppercase tracking-wider text-muted-foreground mb-2">Vendors</div>
                    <div className="flex flex-wrap gap-1.5">
                      {openBooking.vendorIds.map((id) => (
                        <span key={id} className="text-xs px-2 py-1 rounded-full bg-secondary text-secondary-foreground">
                          {vendorById(id)?.name}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setOpenId(null)}>Close</Button>
                <Button onClick={() => { const b = openBooking; setOpenId(null); setBookingDialog({ open: true, initial: b }); }}>
                  <Pencil className="h-4 w-4 mr-1.5" />Edit booking
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>

      <BookingDialog
        open={bookingDialog.open}
        onOpenChange={(o) => setBookingDialog((s) => ({ ...s, open: o }))}
        initial={bookingDialog.initial ?? null}
        presetDate={bookingDialog.date}
      />
      <EnquiryDialog
        open={enquiryDialog.open}
        onOpenChange={(o) => setEnquiryDialog((s) => ({ ...s, open: o }))}
        presetDate={enquiryDialog.date}
      />
    </div>
  );
}
