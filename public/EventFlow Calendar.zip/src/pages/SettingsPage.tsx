import { useState } from "react";
import { Plus, Trash2, Pencil, Save, X } from "lucide-react";
import PageHeader from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import {
  useEventTypes, addEventType, removeEventType,
  useMenuTemplates, addMenuTemplate, updateMenuTemplate, removeMenuTemplate,
  type MenuPlateTemplate,
} from "@/data/store";
import { formatINR } from "@/data/mock";
import { toast } from "sonner";

export default function SettingsPage() {
  const eventTypes = useEventTypes();
  const templates = useMenuTemplates();
  const [newType, setNewType] = useState("");
  const [draft, setDraft] = useState<Omit<MenuPlateTemplate, "id">>({ name: "", course: "Main", items: "", pricePerPlate: 0 });
  const [editingId, setEditingId] = useState<string | null>(null);
  const [edit, setEdit] = useState<Partial<MenuPlateTemplate>>({});

  const startEdit = (m: MenuPlateTemplate) => { setEditingId(m.id); setEdit(m); };
  const saveEdit = () => {
    if (!editingId) return;
    updateMenuTemplate(editingId, edit);
    setEditingId(null); setEdit({});
    toast.success("Template updated");
  };

  return (
    <div className="space-y-8">
      <PageHeader title="Settings" description="Define reusable constants used across the workspace." />

      <Tabs defaultValue="event-types" className="w-full">
        <TabsList>
          <TabsTrigger value="event-types">Event types</TabsTrigger>
          <TabsTrigger value="menu-plates">Menu plates</TabsTrigger>
        </TabsList>

        <TabsContent value="event-types">
          <Card className="p-6">
            <div className="mb-4">
              <h2 className="font-serif-display text-xl">Event types</h2>
              <p className="text-sm text-muted-foreground">Available in enquiries and bookings.</p>
            </div>
            <div className="flex flex-wrap gap-2 mb-4">
              {eventTypes.map((t) => (
                <Badge key={t} variant="secondary" className="px-3 py-1.5 gap-2">
                  {t}
                  <button onClick={() => removeEventType(t)} className="hover:text-destructive">
                    <X className="h-3 w-3" />
                  </button>
                </Badge>
              ))}
              {eventTypes.length === 0 && <p className="text-sm text-muted-foreground">No event types yet.</p>}
            </div>
            <div className="flex gap-2 max-w-md">
              <Input
                placeholder="e.g. Anniversary"
                value={newType}
                onChange={(e) => setNewType(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter") { addEventType(newType); setNewType(""); } }}
              />
              <Button onClick={() => { addEventType(newType); setNewType(""); }}>
                <Plus className="h-4 w-4" /> Add
              </Button>
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="menu-plates">
          <Card className="p-6">
            <div className="mb-4">
              <h2 className="font-serif-display text-xl">Menu plate templates</h2>
              <p className="text-sm text-muted-foreground">Reusable plate definitions for booking menus.</p>
            </div>

            <div className="space-y-2 mb-6">
              {templates.map((m) => (
                <div key={m.id} className="border border-border rounded-md p-3">
                  {editingId === m.id ? (
                    <div className="grid md:grid-cols-5 gap-2 items-end">
                      <div><Label className="text-xs">Name</Label><Input value={edit.name ?? ""} onChange={(e) => setEdit({ ...edit, name: e.target.value })} /></div>
                      <div><Label className="text-xs">Course</Label><Input value={edit.course ?? ""} onChange={(e) => setEdit({ ...edit, course: e.target.value })} /></div>
                      <div className="md:col-span-2"><Label className="text-xs">Items</Label><Input value={edit.items ?? ""} onChange={(e) => setEdit({ ...edit, items: e.target.value })} /></div>
                      <div><Label className="text-xs">Price / plate</Label><Input type="number" value={edit.pricePerPlate ?? 0} onChange={(e) => setEdit({ ...edit, pricePerPlate: Number(e.target.value) })} /></div>
                      <div className="md:col-span-5 flex gap-2 justify-end">
                        <Button size="sm" variant="ghost" onClick={() => { setEditingId(null); setEdit({}); }}><X className="h-4 w-4" /> Cancel</Button>
                        <Button size="sm" onClick={saveEdit}><Save className="h-4 w-4" /> Save</Button>
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center justify-between gap-4">
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{m.name}</span>
                          <Badge variant="outline">{m.course}</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground truncate">{m.items}</p>
                      </div>
                      <div className="flex items-center gap-3 shrink-0">
                        <span className="text-sm font-medium">{formatINR(m.pricePerPlate)}</span>
                        <Button size="icon" variant="ghost" onClick={() => startEdit(m)}><Pencil className="h-4 w-4" /></Button>
                        <Button size="icon" variant="ghost" onClick={() => removeMenuTemplate(m.id)}><Trash2 className="h-4 w-4" /></Button>
                      </div>
                    </div>
                  )}
                </div>
              ))}
              {templates.length === 0 && <p className="text-sm text-muted-foreground">No templates yet.</p>}
            </div>

            <div className="border-t border-border pt-4">
              <h3 className="text-sm font-medium mb-3">Add new template</h3>
              <div className="grid md:grid-cols-5 gap-2 items-end">
                <div><Label className="text-xs">Name</Label><Input value={draft.name} onChange={(e) => setDraft({ ...draft, name: e.target.value })} placeholder="e.g. Veg Thali" /></div>
                <div><Label className="text-xs">Course</Label><Input value={draft.course} onChange={(e) => setDraft({ ...draft, course: e.target.value })} /></div>
                <div className="md:col-span-2"><Label className="text-xs">Items</Label><Input value={draft.items} onChange={(e) => setDraft({ ...draft, items: e.target.value })} placeholder="Comma separated dishes" /></div>
                <div><Label className="text-xs">Price / plate</Label><Input type="number" value={draft.pricePerPlate} onChange={(e) => setDraft({ ...draft, pricePerPlate: Number(e.target.value) })} /></div>
                <div className="md:col-span-5 flex justify-end">
                  <Button onClick={() => {
                    if (!draft.name.trim()) { toast.error("Name required"); return; }
                    addMenuTemplate(draft);
                    setDraft({ name: "", course: "Main", items: "", pricePerPlate: 0 });
                    toast.success("Template added");
                  }}>
                    <Plus className="h-4 w-4" /> Add template
                  </Button>
                </div>
              </div>
            </div>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
