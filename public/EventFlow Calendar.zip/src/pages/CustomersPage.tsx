import { useState } from "react";
import PageHeader from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { useCustomers, useBookings } from "@/data/store";
import { formatINR } from "@/data/mock";
import { Mail, Phone, Pencil, LayoutGrid, List } from "lucide-react";
import CustomerDialog from "@/components/dialogs/CustomerDialog";
import type { Customer } from "@/data/mock";
import { cn } from "@/lib/utils";

export default function CustomersPage() {
  const customers = useCustomers();
  const bookings = useBookings();
  const [view, setView] = useState<"grid" | "list">("grid");
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Customer | null>(null);

  const startEdit = (c: Customer) => { setEditing(c); setOpen(true); };
  const eventsFor = (id: string) => bookings.filter((b) => b.customerId === id).length;

  return (
    <div>
      <PageHeader
        eyebrow="Directory"
        title="Customers"
        description="Auto-created when an enquiry is logged. Edit details inline."
        actions={
          <div className="inline-flex rounded-md border border-border overflow-hidden">
            <button onClick={() => setView("grid")} className={cn("px-2.5 py-1.5", view === "grid" ? "bg-primary text-primary-foreground" : "bg-card text-muted-foreground")}><LayoutGrid className="h-4 w-4" /></button>
            <button onClick={() => setView("list")} className={cn("px-2.5 py-1.5", view === "list" ? "bg-primary text-primary-foreground" : "bg-card text-muted-foreground")}><List className="h-4 w-4" /></button>
          </div>
        }
      />

      {view === "grid" ? (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {customers.map((c) => (
            <div key={c.id} className="rounded-2xl border border-border bg-card p-6 shadow-soft hover:shadow-elegant transition-shadow">
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-start gap-3 min-w-0">
                  <div className="h-12 w-12 rounded-full bg-primary/10 text-primary flex items-center justify-center font-serif-display text-xl shrink-0">
                    {c.name.split(" ").map((n) => n[0]).slice(0, 2).join("")}
                  </div>
                  <div className="min-w-0">
                    <div className="font-serif-display text-xl leading-tight truncate">{c.name}</div>
                    {c.company && <div className="text-xs text-muted-foreground mt-0.5 truncate">{c.company}</div>}
                  </div>
                </div>
                <Button variant="ghost" size="icon" onClick={() => startEdit(c)}><Pencil className="h-4 w-4" /></Button>
              </div>
              <div className="mt-4 space-y-1.5 text-sm">
                <div className="flex items-center gap-2 text-muted-foreground"><Mail className="h-3.5 w-3.5" />{c.email}</div>
                <div className="flex items-center gap-2 text-muted-foreground"><Phone className="h-3.5 w-3.5" />{c.phone}</div>
              </div>
              <div className="mt-5 pt-4 border-t border-border grid grid-cols-3 gap-2 text-center">
                <div><div className="text-xs text-muted-foreground">Since</div><div className="text-sm font-medium">{new Date(c.since).getFullYear()}</div></div>
                <div><div className="text-xs text-muted-foreground">Events</div><div className="text-sm font-medium">{eventsFor(c.id)}</div></div>
                <div><div className="text-xs text-muted-foreground">Spend</div><div className="text-sm font-medium">{formatINR(c.totalSpend)}</div></div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="rounded-2xl border border-border bg-card shadow-soft overflow-hidden">
          <div className="hidden md:grid grid-cols-[1.4fr_1.4fr_1fr_0.6fr_1fr_0.4fr] gap-4 px-6 py-3 bg-surface text-xs uppercase tracking-wider text-muted-foreground border-b border-border">
            <div>Name</div><div>Email</div><div>Phone</div><div>Events</div><div>Spend</div><div></div>
          </div>
          {customers.map((c) => (
            <div key={c.id} className="grid grid-cols-1 md:grid-cols-[1.4fr_1.4fr_1fr_0.6fr_1fr_0.4fr] gap-2 md:gap-4 px-6 py-4 border-b border-border last:border-0 hover:bg-surface/60 items-center">
              <div>
                <div className="font-medium">{c.name}</div>
                {c.company && <div className="text-xs text-muted-foreground">{c.company}</div>}
              </div>
              <div className="text-sm text-muted-foreground">{c.email}</div>
              <div className="text-sm text-muted-foreground">{c.phone}</div>
              <div className="text-sm">{eventsFor(c.id)}</div>
              <div className="text-sm font-medium">{formatINR(c.totalSpend)}</div>
              <div className="text-right"><Button variant="ghost" size="icon" onClick={() => startEdit(c)}><Pencil className="h-4 w-4" /></Button></div>
            </div>
          ))}
        </div>
      )}

      <CustomerDialog open={open} onOpenChange={setOpen} initial={editing} />
    </div>
  );
}
