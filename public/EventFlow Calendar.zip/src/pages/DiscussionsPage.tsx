import { useMemo, useState } from "react";
import PageHeader from "@/components/PageHeader";
import { bookings, customerById, discussions, DiscussionMessage } from "@/data/mock";
import { cn } from "@/lib/utils";
import { Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function DiscussionsPage() {
  const [activeId, setActiveId] = useState(bookings[0]?.id ?? "");
  const [messages, setMessages] = useState<DiscussionMessage[]>(discussions);
  const [draft, setDraft] = useState("");

  const threadBookings = useMemo(() => bookings.filter((b) => b.status !== "cancelled"), []);
  const thread = messages.filter((m) => m.bookingId === activeId);
  const active = bookings.find((b) => b.id === activeId);

  const send = () => {
    if (!draft.trim() || !active) return;
    setMessages((m) => [
      ...m,
      {
        id: `m${Date.now()}`,
        bookingId: active.id,
        author: "Atelier",
        role: "owner",
        message: draft.trim(),
        at: new Date().toISOString(),
      },
    ]);
    setDraft("");
  };

  return (
    <div>
      <PageHeader
        eyebrow="Collaboration"
        title="Discussions"
        description="Shared threads between owner, customer and vendors per event."
      />

      <div className="grid grid-cols-1 md:grid-cols-[280px_1fr] gap-4 rounded-2xl border border-border bg-card shadow-soft overflow-hidden min-h-[560px]">
        <aside className="border-r border-border bg-surface">
          <div className="px-4 py-3 text-xs uppercase tracking-wider text-muted-foreground border-b border-border">
            Event threads
          </div>
          <div className="divide-y divide-border">
            {threadBookings.map((b) => {
              const c = customerById(b.customerId);
              const count = messages.filter((m) => m.bookingId === b.id).length;
              return (
                <button
                  key={b.id}
                  onClick={() => setActiveId(b.id)}
                  className={cn(
                    "w-full text-left px-4 py-3 hover:bg-background",
                    activeId === b.id && "bg-background"
                  )}
                >
                  <div className="font-medium truncate">{b.title}</div>
                  <div className="text-xs text-muted-foreground flex items-center justify-between mt-0.5">
                    <span className="truncate">{c?.name}</span>
                    <span>{count} msg</span>
                  </div>
                </button>
              );
            })}
          </div>
        </aside>

        <section className="flex flex-col">
          <div className="px-5 py-4 border-b border-border">
            <div className="font-serif-display text-2xl">{active?.title}</div>
            <div className="text-xs text-muted-foreground">{active && new Date(active.date).toLocaleDateString("en-US", { dateStyle: "full" })}</div>
          </div>

          <div className="flex-1 px-5 py-4 space-y-4 overflow-y-auto">
            {thread.map((m) => (
              <div key={m.id} className={cn("flex gap-3", m.role === "owner" && "flex-row-reverse")}>
                <div className={cn(
                  "h-8 w-8 rounded-full shrink-0 flex items-center justify-center text-xs font-medium",
                  m.role === "owner" && "bg-primary text-primary-foreground",
                  m.role === "customer" && "bg-accent text-accent-foreground",
                  m.role === "vendor" && "bg-secondary text-secondary-foreground"
                )}>
                  {m.author.split(" ").map(w => w[0]).slice(0, 2).join("")}
                </div>
                <div className={cn("max-w-md", m.role === "owner" && "text-right")}>
                  <div className="text-xs text-muted-foreground mb-1">
                    {m.author} · <span className="capitalize">{m.role}</span> · {new Date(m.at).toLocaleString("en-US", { dateStyle: "medium", timeStyle: "short" })}
                  </div>
                  <div className={cn(
                    "inline-block px-4 py-2.5 rounded-2xl text-sm",
                    m.role === "owner" ? "bg-primary text-primary-foreground rounded-tr-sm" : "bg-secondary text-secondary-foreground rounded-tl-sm"
                  )}>
                    {m.message}
                  </div>
                </div>
              </div>
            ))}
            {thread.length === 0 && (
              <div className="text-center text-muted-foreground py-12 text-sm">No messages yet. Start the conversation.</div>
            )}
          </div>

          <div className="border-t border-border p-3 flex gap-2">
            <Input
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && send()}
              placeholder="Write a message…"
            />
            <Button onClick={send}><Send className="h-4 w-4" /></Button>
          </div>
        </section>
      </div>
    </div>
  );
}
